const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const { v4: uuidv4 } = require('uuid');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

// Security middleware
app.use(helmet());
app.use(cors());
app.use(express.json());

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: 'Too many requests from this IP, please try again later.'
});
app.use('/api/', limiter);

// In-memory storage for sessions and users
const sessions = new Map();
const userSessions = new Map(); // deviceId -> sessionId mapping
const sessionCodes = new Map(); // code -> sessionId mapping

// Session types
const SESSION_TYPES = {
  DESK: 'desk',
  TEAM: 'team',
  CLASS: 'class'
};

// User roles
const USER_ROLES = {
  ADMIN: 'admin',
  MEMBER: 'member',
  STUDENT: 'student'
};

// Generate unique session code (6 digits)
function generateSessionCode() {
  let code;
  do {
    code = Math.floor(100000 + Math.random() * 900000).toString();
  } while (sessionCodes.has(code));
  return code;
}

// Create session endpoint
app.post('/api/sessions/create', (req, res) => {
  try {
    const { type, creatorId, creatorName, deviceId } = req.body;
    
    if (!type || !creatorId || !creatorName || !deviceId) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    if (!Object.values(SESSION_TYPES).includes(type)) {
      return res.status(400).json({ error: 'Invalid session type' });
    }

    // Check if device is already in a session
    if (userSessions.has(deviceId)) {
      return res.status(409).json({ error: 'Device already in a session' });
    }

    const sessionId = uuidv4();
    const sessionCode = generateSessionCode();
    const sessionLink = `https://p2p.app/s/${sessionId}`;
    
    const session = {
      id: sessionId,
      type: type,
      code: sessionCode,
      link: sessionLink,
      createdAt: new Date().toISOString(),
      creator: {
        id: creatorId,
        name: creatorName,
        deviceId: deviceId,
        role: USER_ROLES.ADMIN
      },
      participants: new Map(),
      isActive: true
    };

    // Add creator as first participant
    session.participants.set(deviceId, {
      id: creatorId,
      name: creatorName,
      deviceId: deviceId,
      role: USER_ROLES.ADMIN,
      socketId: null,
      joinedAt: new Date().toISOString(),
      isScreenSharing: false,
      isMuted: false
    });

    sessions.set(sessionId, session);
    sessionCodes.set(sessionCode, sessionId);
    userSessions.set(deviceId, sessionId);

    res.json({
      sessionId: sessionId,
      sessionCode: sessionCode,
      sessionLink: sessionLink,
      type: type,
      message: 'Session created successfully'
    });

  } catch (error) {
    console.error('Error creating session:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Join session by ID endpoint
app.post('/api/sessions/join/:sessionId', (req, res) => {
  try {
    const { sessionId } = req.params;
    const { userId, userName, deviceId } = req.body;

    if (!userId || !userName || !deviceId) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    // Check if device is already in a session
    if (userSessions.has(deviceId)) {
      const existingSessionId = userSessions.get(deviceId);
      if (existingSessionId !== sessionId) {
        return res.status(409).json({ error: 'Device already in another session' });
      }
    }

    const session = sessions.get(sessionId);
    if (!session) {
      return res.status(404).json({ error: 'Session not found' });
    }

    if (!session.isActive) {
      return res.status(410).json({ error: 'Session is no longer active' });
    }

    // Determine user role based on session type
    let userRole = USER_ROLES.MEMBER;
    if (session.type === SESSION_TYPES.CLASS) {
      userRole = USER_ROLES.STUDENT;
    }

    const participant = {
      id: userId,
      name: userName,
      deviceId: deviceId,
      role: userRole,
      socketId: null,
      joinedAt: new Date().toISOString(),
      isScreenSharing: false,
      isMuted: false
    };

    session.participants.set(deviceId, participant);
    userSessions.set(deviceId, sessionId);

    res.json({
      sessionId: sessionId,
      sessionType: session.type,
      userRole: userRole,
      message: 'Joined session successfully'
    });

  } catch (error) {
    console.error('Error joining session:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Join session by code endpoint
app.post('/api/sessions/join-by-code', (req, res) => {
  try {
    const { code, userId, userName, deviceId } = req.body;

    if (!code || !userId || !userName || !deviceId) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const sessionId = sessionCodes.get(code);
    if (!sessionId) {
      return res.status(404).json({ error: 'Invalid session code' });
    }

    // Redirect to join by ID
    req.params.sessionId = sessionId;
    return app._router.handle(req, res);

  } catch (error) {
    console.error('Error joining session by code:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get session info endpoint
app.get('/api/sessions/:sessionId', (req, res) => {
  try {
    const { sessionId } = req.params;
    const session = sessions.get(sessionId);

    if (!session) {
      return res.status(404).json({ error: 'Session not found' });
    }

    const participantsList = Array.from(session.participants.values()).map(p => ({
      id: p.id,
      name: p.name,
      role: p.role,
      joinedAt: p.joinedAt,
      isScreenSharing: p.isScreenSharing,
      isMuted: p.isMuted
    }));

    res.json({
      sessionId: session.id,
      type: session.type,
      code: session.code,
      link: session.link,
      createdAt: session.createdAt,
      creator: {
        id: session.creator.id,
        name: session.creator.name,
        role: session.creator.role
      },
      participants: participantsList,
      isActive: session.isActive
    });

  } catch (error) {
    console.error('Error getting session info:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// WebSocket connection handling
io.on('connection', (socket) => {
  console.log('New client connected:', socket.id);

  // Join session room
  socket.on('join-session', (data) => {
    const { sessionId, deviceId } = data;
    
    const session = sessions.get(sessionId);
    if (!session || !session.participants.has(deviceId)) {
      socket.emit('error', { message: 'Invalid session or user not authorized' });
      return;
    }

    // Update participant socket ID
    const participant = session.participants.get(deviceId);
    participant.socketId = socket.id;

    // Join socket room
    socket.join(sessionId);
    socket.sessionId = sessionId;
    socket.deviceId = deviceId;

    // Notify other participants
    socket.to(sessionId).emit('user-joined', {
      userId: participant.id,
      userName: participant.name,
      userRole: participant.role
    });

    socket.emit('joined-session', {
      sessionId: sessionId,
      participants: Array.from(session.participants.values()).map(p => ({
        id: p.id,
        name: p.name,
        role: p.role,
        isScreenSharing: p.isScreenSharing,
        isMuted: p.isMuted
      }))
    });
  });

  // WebRTC signaling
  socket.on('offer', (data) => {
    socket.to(data.target).emit('offer', {
      offer: data.offer,
      sender: socket.deviceId
    });
  });

  socket.on('answer', (data) => {
    socket.to(data.target).emit('answer', {
      answer: data.answer,
      sender: socket.deviceId
    });
  });

  socket.on('ice-candidate', (data) => {
    socket.to(data.target).emit('ice-candidate', {
      candidate: data.candidate,
      sender: socket.deviceId
    });
  });

  // Screen sharing events
  socket.on('start-screen-share', () => {
    if (socket.sessionId && socket.deviceId) {
      const session = sessions.get(socket.sessionId);
      if (session && session.participants.has(socket.deviceId)) {
        const participant = session.participants.get(socket.deviceId);
        participant.isScreenSharing = true;
        
        socket.to(socket.sessionId).emit('user-started-screen-share', {
          userId: participant.id,
          userName: participant.name
        });
      }
    }
  });

  socket.on('stop-screen-share', () => {
    if (socket.sessionId && socket.deviceId) {
      const session = sessions.get(socket.sessionId);
      if (session && session.participants.has(socket.deviceId)) {
        const participant = session.participants.get(socket.deviceId);
        participant.isScreenSharing = false;
        
        socket.to(socket.sessionId).emit('user-stopped-screen-share', {
          userId: participant.id,
          userName: participant.name
        });
      }
    }
  });

  // Control request events
  socket.on('request-control', (data) => {
    const { targetDeviceId } = data;
    if (socket.sessionId) {
      const session = sessions.get(socket.sessionId);
      if (session && session.participants.has(targetDeviceId)) {
        const targetParticipant = session.participants.get(targetDeviceId);
        if (targetParticipant.socketId) {
          io.to(targetParticipant.socketId).emit('control-request', {
            requesterId: socket.deviceId,
            requesterName: session.participants.get(socket.deviceId).name
          });
        }
      }
    }
  });

  socket.on('control-response', (data) => {
    const { requesterId, granted } = data;
    if (socket.sessionId) {
      const session = sessions.get(socket.sessionId);
      if (session && session.participants.has(requesterId)) {
        const requesterParticipant = session.participants.get(requesterId);
        if (requesterParticipant.socketId) {
          io.to(requesterParticipant.socketId).emit('control-response', {
            granted: granted,
            targetId: socket.deviceId
          });
        }
      }
    }
  });

  // Disconnect handling
  socket.on('disconnect', () => {
    console.log('Client disconnected:', socket.id);
    
    if (socket.sessionId && socket.deviceId) {
      const session = sessions.get(socket.sessionId);
      if (session && session.participants.has(socket.deviceId)) {
        const participant = session.participants.get(socket.deviceId);
        participant.socketId = null;
        
        // Notify other participants
        socket.to(socket.sessionId).emit('user-left', {
          userId: participant.id,
          userName: participant.name
        });

        // If creator left, end session
        if (participant.role === USER_ROLES.ADMIN) {
          session.isActive = false;
          io.to(socket.sessionId).emit('session-ended', {
            reason: 'Creator left the session'
          });
          
          // Clean up
          sessionCodes.delete(session.code);
          sessions.delete(socket.sessionId);
          
          // Remove all participants from userSessions
          for (const [deviceId, sessionId] of userSessions.entries()) {
            if (sessionId === socket.sessionId) {
              userSessions.delete(deviceId);
            }
          }
        }
      }
    }
  });
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

// Start server
const PORT = process.env.PORT || 3000;
server.listen(PORT, '0.0.0.0', () => {
  console.log(`Signaling server running on port ${PORT}`);
  console.log(`Health check: http://localhost:${PORT}/health`);
});

