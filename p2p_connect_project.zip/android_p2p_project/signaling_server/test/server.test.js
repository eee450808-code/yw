const request = require('supertest');
const WebSocket = require('ws');
const app = require('../server');

describe('Signaling Server Integration Tests', () => {
    let server;
    let wsServer;
    
    beforeAll((done) => {
        server = app.listen(0, () => {
            const port = server.address().port;
            wsServer = new WebSocket.Server({ port: port + 1 });
            done();
        });
    });
    
    afterAll((done) => {
        if (wsServer) {
            wsServer.close();
        }
        if (server) {
            server.close(done);
        } else {
            done();
        }
    });

    describe('Health Check', () => {
        test('GET /health should return 200', async () => {
            const response = await request(app)
                .get('/health')
                .expect(200);
            
            expect(response.body).toHaveProperty('status', 'ok');
            expect(response.body).toHaveProperty('timestamp');
        });
    });

    describe('Session Management', () => {
        test('POST /api/sessions should create a new session', async () => {
            const sessionData = {
                sessionType: 'desk',
                userId: 'test-user-123',
                userName: 'Test User',
                deviceId: 'test-device-123'
            };

            const response = await request(app)
                .post('/api/sessions')
                .send(sessionData)
                .expect(201);

            expect(response.body).toHaveProperty('sessionId');
            expect(response.body).toHaveProperty('sessionCode');
            expect(response.body).toHaveProperty('sessionLink');
            expect(response.body.sessionType).toBe('desk');
            expect(response.body.createdBy).toBe('test-user-123');
        });

        test('POST /api/sessions should reject invalid session type', async () => {
            const sessionData = {
                sessionType: 'invalid',
                userId: 'test-user-123',
                userName: 'Test User',
                deviceId: 'test-device-123'
            };

            const response = await request(app)
                .post('/api/sessions')
                .send(sessionData)
                .expect(400);

            expect(response.body).toHaveProperty('error');
        });

        test('POST /api/sessions should reject missing required fields', async () => {
            const sessionData = {
                sessionType: 'desk'
                // Missing userId, userName, deviceId
            };

            const response = await request(app)
                .post('/api/sessions')
                .send(sessionData)
                .expect(400);

            expect(response.body).toHaveProperty('error');
        });

        test('GET /api/sessions/:sessionId should return session info', async () => {
            // First create a session
            const sessionData = {
                sessionType: 'team',
                userId: 'test-user-456',
                userName: 'Test User 2',
                deviceId: 'test-device-456'
            };

            const createResponse = await request(app)
                .post('/api/sessions')
                .send(sessionData)
                .expect(201);

            const sessionId = createResponse.body.sessionId;

            // Then get session info
            const response = await request(app)
                .get(`/api/sessions/${sessionId}`)
                .expect(200);

            expect(response.body.sessionId).toBe(sessionId);
            expect(response.body.sessionType).toBe('team');
            expect(response.body.createdBy).toBe('test-user-456');
        });

        test('GET /api/sessions/:sessionId should return 404 for non-existent session', async () => {
            const response = await request(app)
                .get('/api/sessions/non-existent-session')
                .expect(404);

            expect(response.body).toHaveProperty('error');
        });
    });

    describe('Session Joining', () => {
        let testSessionId;
        let testSessionCode;

        beforeEach(async () => {
            // Create a test session before each test
            const sessionData = {
                sessionType: 'desk',
                userId: 'creator-123',
                userName: 'Creator',
                deviceId: 'creator-device-123'
            };

            const response = await request(app)
                .post('/api/sessions')
                .send(sessionData);

            testSessionId = response.body.sessionId;
            testSessionCode = response.body.sessionCode;
        });

        test('POST /api/sessions/:sessionId/join should allow joining session', async () => {
            const joinData = {
                userId: 'joiner-123',
                userName: 'Joiner',
                deviceId: 'joiner-device-123'
            };

            const response = await request(app)
                .post(`/api/sessions/${testSessionId}/join`)
                .send(joinData)
                .expect(200);

            expect(response.body).toHaveProperty('sessionId', testSessionId);
            expect(response.body).toHaveProperty('sessionType');
            expect(response.body).toHaveProperty('userRole');
        });

        test('POST /api/sessions/join-by-code should allow joining by code', async () => {
            const joinData = {
                sessionCode: testSessionCode,
                userId: 'joiner-456',
                userName: 'Joiner 2',
                deviceId: 'joiner-device-456'
            };

            const response = await request(app)
                .post('/api/sessions/join-by-code')
                .send(joinData)
                .expect(200);

            expect(response.body).toHaveProperty('sessionId', testSessionId);
            expect(response.body).toHaveProperty('sessionType');
            expect(response.body).toHaveProperty('userRole');
        });

        test('POST /api/sessions/:sessionId/join should reject duplicate device', async () => {
            const joinData = {
                userId: 'joiner-789',
                userName: 'Joiner 3',
                deviceId: 'creator-device-123' // Same device as creator
            };

            const response = await request(app)
                .post(`/api/sessions/${testSessionId}/join`)
                .send(joinData)
                .expect(400);

            expect(response.body).toHaveProperty('error');
            expect(response.body.error).toContain('already in a session');
        });

        test('POST /api/sessions/join-by-code should reject invalid code', async () => {
            const joinData = {
                sessionCode: 'INVALID',
                userId: 'joiner-999',
                userName: 'Joiner 4',
                deviceId: 'joiner-device-999'
            };

            const response = await request(app)
                .post('/api/sessions/join-by-code')
                .send(joinData)
                .expect(404);

            expect(response.body).toHaveProperty('error');
        });
    });

    describe('Session Participants', () => {
        let testSessionId;

        beforeEach(async () => {
            // Create a test session
            const sessionData = {
                sessionType: 'team',
                userId: 'creator-456',
                userName: 'Team Creator',
                deviceId: 'creator-device-456'
            };

            const response = await request(app)
                .post('/api/sessions')
                .send(sessionData);

            testSessionId = response.body.sessionId;

            // Add a participant
            const joinData = {
                userId: 'member-123',
                userName: 'Team Member',
                deviceId: 'member-device-123'
            };

            await request(app)
                .post(`/api/sessions/${testSessionId}/join`)
                .send(joinData);
        });

        test('GET /api/sessions/:sessionId/participants should return participants list', async () => {
            const response = await request(app)
                .get(`/api/sessions/${testSessionId}/participants`)
                .expect(200);

            expect(response.body).toHaveProperty('participants');
            expect(Array.isArray(response.body.participants)).toBe(true);
            expect(response.body.participants.length).toBe(2); // Creator + 1 member
        });

        test('DELETE /api/sessions/:sessionId/participants/:userId should remove participant', async () => {
            const response = await request(app)
                .delete(`/api/sessions/${testSessionId}/participants/member-123`)
                .expect(200);

            expect(response.body).toHaveProperty('message');

            // Verify participant was removed
            const participantsResponse = await request(app)
                .get(`/api/sessions/${testSessionId}/participants`)
                .expect(200);

            expect(participantsResponse.body.participants.length).toBe(1); // Only creator left
        });
    });

    describe('Rate Limiting', () => {
        test('Should apply rate limiting to session creation', async () => {
            const sessionData = {
                sessionType: 'desk',
                userId: 'rate-test-user',
                userName: 'Rate Test User',
                deviceId: 'rate-test-device'
            };

            // Make multiple rapid requests
            const promises = [];
            for (let i = 0; i < 15; i++) {
                promises.push(
                    request(app)
                        .post('/api/sessions')
                        .send({
                            ...sessionData,
                            deviceId: `rate-test-device-${i}`
                        })
                );
            }

            const responses = await Promise.all(promises);
            
            // Some requests should be rate limited (429 status)
            const rateLimitedResponses = responses.filter(res => res.status === 429);
            expect(rateLimitedResponses.length).toBeGreaterThan(0);
        });
    });

    describe('Input Validation and Security', () => {
        test('Should sanitize user input', async () => {
            const sessionData = {
                sessionType: 'desk',
                userId: '<script>alert("xss")</script>',
                userName: '<img src=x onerror=alert("xss")>',
                deviceId: 'test-device'
            };

            const response = await request(app)
                .post('/api/sessions')
                .send(sessionData)
                .expect(201);

            // Check that HTML is escaped/sanitized
            expect(response.body.createdBy).not.toContain('<script>');
        });

        test('Should reject oversized payloads', async () => {
            const largeString = 'a'.repeat(10000); // 10KB string
            const sessionData = {
                sessionType: 'desk',
                userId: largeString,
                userName: largeString,
                deviceId: 'test-device'
            };

            const response = await request(app)
                .post('/api/sessions')
                .send(sessionData)
                .expect(400);

            expect(response.body).toHaveProperty('error');
        });

        test('Should validate session type enum', async () => {
            const sessionData = {
                sessionType: 'invalid_type',
                userId: 'test-user',
                userName: 'Test User',
                deviceId: 'test-device'
            };

            const response = await request(app)
                .post('/api/sessions')
                .send(sessionData)
                .expect(400);

            expect(response.body.error).toContain('Invalid session type');
        });
    });

    describe('Error Handling', () => {
        test('Should handle malformed JSON', async () => {
            const response = await request(app)
                .post('/api/sessions')
                .set('Content-Type', 'application/json')
                .send('{"invalid": json}')
                .expect(400);

            expect(response.body).toHaveProperty('error');
        });

        test('Should handle missing Content-Type', async () => {
            const response = await request(app)
                .post('/api/sessions')
                .send('sessionType=desk&userId=test')
                .expect(400);

            expect(response.body).toHaveProperty('error');
        });

        test('Should return proper error for non-existent endpoints', async () => {
            const response = await request(app)
                .get('/api/non-existent-endpoint')
                .expect(404);

            expect(response.body).toHaveProperty('error');
        });
    });
});

