# خادم الإشارة (Signaling Server) لتطبيق P2P

هذا الخادم مسؤول عن إدارة الجلسات والتواصل بين المشاركين في تطبيق P2P Android.

## الميزات

- إنشاء جلسات بأنواع مختلفة (Desk, Team, Class)
- إدارة المشاركين والأذونات
- منع انضمام جهاز لأكثر من جلسة واحدة
- دعم WebRTC signaling (offer, answer, ICE candidates)
- إدارة مشاركة الشاشة وطلبات التحكم
- حماية من Rate Limiting
- دعم CORS للتطبيقات الخارجية

## التثبيت والتشغيل

### المتطلبات المسبقة
- Node.js (الإصدار 16 أو أحدث)
- npm أو yarn

### خطوات التثبيت

1. تثبيت التبعيات:
```bash
npm install
```

2. تشغيل الخادم في وضع التطوير:
```bash
npm run dev
```

3. تشغيل الخادم في وضع الإنتاج:
```bash
npm start
```

الخادم سيعمل على المنفذ 3000 افتراضيًا. يمكنك تغيير المنفذ عن طريق تعيين متغير البيئة `PORT`.

## API Endpoints

### إنشاء جلسة جديدة
```
POST /api/sessions/create
Content-Type: application/json

{
  "type": "desk|team|class",
  "creatorId": "user_id",
  "creatorName": "User Name",
  "deviceId": "unique_device_id"
}
```

### الانضمام لجلسة بالمعرف
```
POST /api/sessions/join/:sessionId
Content-Type: application/json

{
  "userId": "user_id",
  "userName": "User Name",
  "deviceId": "unique_device_id"
}
```

### الانضمام لجلسة بالكود
```
POST /api/sessions/join-by-code
Content-Type: application/json

{
  "code": "123456",
  "userId": "user_id",
  "userName": "User Name",
  "deviceId": "unique_device_id"
}
```

### الحصول على معلومات الجلسة
```
GET /api/sessions/:sessionId
```

### فحص حالة الخادم
```
GET /health
```

## WebSocket Events

### أحداث الاتصال
- `join-session`: الانضمام لغرفة الجلسة
- `joined-session`: تأكيد الانضمام مع قائمة المشاركين
- `user-joined`: إشعار بانضمام مستخدم جديد
- `user-left`: إشعار بمغادرة مستخدم

### أحداث WebRTC Signaling
- `offer`: إرسال WebRTC offer
- `answer`: إرسال WebRTC answer
- `ice-candidate`: إرسال ICE candidate

### أحداث مشاركة الشاشة
- `start-screen-share`: بدء مشاركة الشاشة
- `stop-screen-share`: إيقاف مشاركة الشاشة
- `user-started-screen-share`: إشعار ببدء مشاركة شاشة مستخدم
- `user-stopped-screen-share`: إشعار بإيقاف مشاركة شاشة مستخدم

### أحداث طلب التحكم
- `request-control`: طلب التحكم في جهاز آخر
- `control-request`: إشعار بطلب تحكم
- `control-response`: رد على طلب التحكم
- `control-response`: إشعار برد على طلب التحكم

### أحداث إدارة الجلسة
- `session-ended`: إشعار بانتهاء الجلسة

## أنواع الجلسات والأذونات

### Desk (مكتب)
- جلسة 1:1 أو مشاركة بسيطة
- التحكم يتطلب إذن من المستقبل

### Team (فريق)
- مدير + أعضاء
- المدير يمكنه رؤية شاشات جميع الأعضاء
- طلب/منح التحكم متاح للجميع

### Class (فصل دراسي)
- معلم + طلاب
- المعلم يرى شاشات الطلاب فقط
- الطلاب لا يرون شاشات بعضهم البعض
- طلب التحكم يجب أن يوافق عليه الطالب

## الأمان

- Rate limiting: 100 طلب لكل 15 دقيقة لكل IP
- Helmet.js للحماية من الثغرات الشائعة
- CORS مُفعل للسماح بالوصول من التطبيقات الخارجية
- التحقق من صحة البيانات المدخلة

## البيئة والنشر

الخادم مُصمم للعمل على `0.0.0.0` للسماح بالوصول الخارجي. يمكن نشره على أي منصة تدعم Node.js مثل:
- Heroku
- AWS EC2
- Google Cloud Platform
- DigitalOcean
- أو أي خادم VPS

تأكد من تعيين متغير البيئة `PORT` إذا كان مطلوبًا من قبل منصة النشر.

