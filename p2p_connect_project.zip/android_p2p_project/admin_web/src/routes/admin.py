from flask import Blueprint, request, jsonify, send_file
from werkzeug.utils import secure_filename
import os
import hashlib
from src.models.app_version import db, AppVersion, ServerConfig, DownloadLog

admin_bp = Blueprint('admin', __name__)

UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'uploads')
ALLOWED_EXTENSIONS = {'apk'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def calculate_sha256(file_path):
    sha256_hash = hashlib.sha256()
    with open(file_path, "rb") as f:
        for byte_block in iter(lambda: f.read(4096), b""):
            sha256_hash.update(byte_block)
    return sha256_hash.hexdigest()

@admin_bp.route('/versions', methods=['GET'])
def get_versions():
    """Get all app versions"""
    versions = AppVersion.query.order_by(AppVersion.version_code.desc()).all()
    return jsonify([version.to_dict() for version in versions])

@admin_bp.route('/versions', methods=['POST'])
def upload_version():
    """Upload a new app version"""
    if 'apk_file' not in request.files:
        return jsonify({'error': 'No APK file provided'}), 400
    
    file = request.files['apk_file']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    if not allowed_file(file.filename):
        return jsonify({'error': 'Invalid file type. Only APK files are allowed'}), 400
    
    version_name = request.form.get('version_name')
    version_code = request.form.get('version_code')
    release_notes = request.form.get('release_notes', '')
    
    if not version_name or not version_code:
        return jsonify({'error': 'Version name and code are required'}), 400
    
    try:
        version_code = int(version_code)
    except ValueError:
        return jsonify({'error': 'Version code must be an integer'}), 400
    
    # Check if version code already exists
    existing_version = AppVersion.query.filter_by(version_code=version_code).first()
    if existing_version:
        return jsonify({'error': 'Version code already exists'}), 400
    
    # Create upload directory if it doesn't exist
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    
    # Save file
    filename = secure_filename(file.filename)
    file_path = os.path.join(UPLOAD_FOLDER, f"{version_name}_{version_code}_{filename}")
    file.save(file_path)
    
    # Calculate file size and SHA256
    file_size = os.path.getsize(file_path)
    sha256_hash = calculate_sha256(file_path)
    
    # Create new version record
    new_version = AppVersion(
        version_name=version_name,
        version_code=version_code,
        apk_file_path=file_path,
        apk_file_size=file_size,
        sha256_hash=sha256_hash,
        release_notes=release_notes
    )
    
    db.session.add(new_version)
    db.session.commit()
    
    return jsonify(new_version.to_dict()), 201

@admin_bp.route('/versions/<int:version_id>', methods=['PUT'])
def update_version(version_id):
    """Update version details"""
    version = AppVersion.query.get_or_404(version_id)
    
    data = request.get_json()
    if 'version_name' in data:
        version.version_name = data['version_name']
    if 'release_notes' in data:
        version.release_notes = data['release_notes']
    if 'is_active' in data:
        version.is_active = data['is_active']
    
    db.session.commit()
    return jsonify(version.to_dict())

@admin_bp.route('/versions/<int:version_id>', methods=['DELETE'])
def delete_version(version_id):
    """Delete a version"""
    version = AppVersion.query.get_or_404(version_id)
    
    # Delete APK file
    if os.path.exists(version.apk_file_path):
        os.remove(version.apk_file_path)
    
    db.session.delete(version)
    db.session.commit()
    
    return jsonify({'message': 'Version deleted successfully'})

@admin_bp.route('/download/<int:version_id>')
def download_apk(version_id):
    """Download APK file"""
    version = AppVersion.query.get_or_404(version_id)
    
    if not version.is_active:
        return jsonify({'error': 'Version is not active'}), 404
    
    if not os.path.exists(version.apk_file_path):
        return jsonify({'error': 'APK file not found'}), 404
    
    # Log download
    download_log = DownloadLog(
        version_id=version_id,
        ip_address=request.remote_addr,
        user_agent=request.headers.get('User-Agent')
    )
    db.session.add(download_log)
    
    # Increment download count
    version.download_count += 1
    db.session.commit()
    
    return send_file(version.apk_file_path, as_attachment=True, 
                     download_name=f"P2P_v{version.version_name}.apk")

@admin_bp.route('/config', methods=['GET'])
def get_configs():
    """Get all server configurations"""
    configs = ServerConfig.query.all()
    return jsonify([config.to_dict() for config in configs])

@admin_bp.route('/config', methods=['POST'])
def create_config():
    """Create or update server configuration"""
    data = request.get_json()
    
    config_key = data.get('config_key')
    config_value = data.get('config_value')
    description = data.get('description', '')
    
    if not config_key or not config_value:
        return jsonify({'error': 'Config key and value are required'}), 400
    
    # Check if config already exists
    existing_config = ServerConfig.query.filter_by(config_key=config_key).first()
    if existing_config:
        existing_config.config_value = config_value
        existing_config.description = description
        db.session.commit()
        return jsonify(existing_config.to_dict())
    
    # Create new config
    new_config = ServerConfig(
        config_key=config_key,
        config_value=config_value,
        description=description
    )
    
    db.session.add(new_config)
    db.session.commit()
    
    return jsonify(new_config.to_dict()), 201

@admin_bp.route('/config/<int:config_id>', methods=['PUT'])
def update_config(config_id):
    """Update server configuration"""
    config = ServerConfig.query.get_or_404(config_id)
    
    data = request.get_json()
    if 'config_value' in data:
        config.config_value = data['config_value']
    if 'description' in data:
        config.description = data['description']
    
    db.session.commit()
    return jsonify(config.to_dict())

@admin_bp.route('/config/<int:config_id>', methods=['DELETE'])
def delete_config(config_id):
    """Delete server configuration"""
    config = ServerConfig.query.get_or_404(config_id)
    db.session.delete(config)
    db.session.commit()
    
    return jsonify({'message': 'Configuration deleted successfully'})

@admin_bp.route('/downloads', methods=['GET'])
def get_download_logs():
    """Get download logs with pagination"""
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 50, type=int)
    
    downloads = DownloadLog.query.order_by(DownloadLog.download_time.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    return jsonify({
        'downloads': [download.to_dict() for download in downloads.items],
        'total': downloads.total,
        'pages': downloads.pages,
        'current_page': page,
        'per_page': per_page
    })

@admin_bp.route('/stats', methods=['GET'])
def get_stats():
    """Get download statistics"""
    total_downloads = DownloadLog.query.count()
    active_versions = AppVersion.query.filter_by(is_active=True).count()
    total_versions = AppVersion.query.count()
    
    # Get download stats by version
    version_stats = db.session.query(
        AppVersion.version_name,
        AppVersion.download_count
    ).order_by(AppVersion.download_count.desc()).limit(10).all()
    
    return jsonify({
        'total_downloads': total_downloads,
        'active_versions': active_versions,
        'total_versions': total_versions,
        'top_versions': [{'version': v[0], 'downloads': v[1]} for v in version_stats]
    })

