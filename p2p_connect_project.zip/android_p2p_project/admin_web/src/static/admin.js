// Initialize Lucide icons
lucide.createIcons();

let currentDownloadPage = 1;
const downloadsPerPage = 20;

// Tab management
function showTab(tabName) {
    // Hide all tab contents
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });
    
    // Remove active class from all tab buttons
    document.querySelectorAll('.tab-button').forEach(button => {
        button.classList.remove('active');
    });
    
    // Show selected tab content
    document.getElementById(tabName).classList.add('active');
    
    // Add active class to clicked button
    event.target.classList.add('active');
    
    // Load data for the selected tab
    if (tabName === 'versions') {
        loadVersions();
    } else if (tabName === 'config') {
        loadConfigs();
    } else if (tabName === 'downloads') {
        loadDownloads();
    }
}

// Load statistics
async function loadStats() {
    try {
        const response = await fetch('/api/admin/stats');
        const stats = await response.json();
        
        document.getElementById('totalDownloads').textContent = stats.total_downloads;
        document.getElementById('activeVersions').textContent = stats.active_versions;
        document.getElementById('totalVersions').textContent = stats.total_versions;
        
        // Load configs count separately
        const configResponse = await fetch('/api/admin/config');
        const configs = await configResponse.json();
        document.getElementById('totalConfigs').textContent = configs.length;
    } catch (error) {
        console.error('Error loading stats:', error);
    }
}

// Load versions
async function loadVersions() {
    try {
        const response = await fetch('/api/admin/versions');
        const versions = await response.json();
        
        const tbody = document.getElementById('versionsTable');
        tbody.innerHTML = '';
        
        versions.forEach(version => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${version.version_name}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${version.version_code}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${formatFileSize(version.apk_file_size)}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${version.download_count}</td>
                <td class="px-6 py-4 whitespace-nowrap">
                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${version.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}">
                        ${version.is_active ? 'Active' : 'Inactive'}
                    </span>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <button onclick="toggleVersionStatus(${version.id}, ${!version.is_active})" class="text-indigo-600 hover:text-indigo-900 mr-3">
                        ${version.is_active ? 'Deactivate' : 'Activate'}
                    </button>
                    <button onclick="downloadVersion(${version.id})" class="text-green-600 hover:text-green-900 mr-3">
                        Download
                    </button>
                    <button onclick="deleteVersion(${version.id})" class="text-red-600 hover:text-red-900">
                        Delete
                    </button>
                </td>
            `;
            tbody.appendChild(row);
        });
    } catch (error) {
        console.error('Error loading versions:', error);
    }
}

// Load configurations
async function loadConfigs() {
    try {
        const response = await fetch('/api/admin/config');
        const configs = await response.json();
        
        const configList = document.getElementById('configList');
        configList.innerHTML = '';
        
        configs.forEach(config => {
            const configCard = document.createElement('div');
            configCard.className = 'bg-gray-50 rounded-lg p-4';
            configCard.innerHTML = `
                <div class="flex justify-between items-start">
                    <div class="flex-1">
                        <h3 class="text-lg font-medium text-gray-900">${config.config_key}</h3>
                        <p class="text-sm text-gray-600 mt-1">${config.description || 'No description'}</p>
                        <p class="text-sm font-mono bg-white px-2 py-1 rounded mt-2 break-all">${config.config_value}</p>
                    </div>
                    <div class="ml-4 flex space-x-2">
                        <button onclick="editConfig(${config.id}, '${config.config_key}', '${config.config_value}', '${config.description || ''}')" class="text-indigo-600 hover:text-indigo-900">
                            Edit
                        </button>
                        <button onclick="deleteConfig(${config.id})" class="text-red-600 hover:text-red-900">
                            Delete
                        </button>
                    </div>
                </div>
            `;
            configList.appendChild(configCard);
        });
    } catch (error) {
        console.error('Error loading configs:', error);
    }
}

// Load downloads
async function loadDownloads(page = 1) {
    try {
        const response = await fetch(`/api/admin/downloads?page=${page}&per_page=${downloadsPerPage}`);
        const data = await response.json();
        
        const tbody = document.getElementById('downloadsTable');
        if (page === 1) {
            tbody.innerHTML = '';
        }
        
        data.downloads.forEach(download => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${formatDate(download.download_time)}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${download.version ? download.version.version_name : 'Unknown'}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${download.ip_address}</td>
                <td class="px-6 py-4 text-sm text-gray-500 max-w-xs truncate">${download.user_agent || 'Unknown'}</td>
            `;
            tbody.appendChild(row);
        });
        
        // Show/hide load more button
        const loadMoreBtn = document.getElementById('loadMoreDownloads');
        if (page >= data.pages) {
            loadMoreBtn.style.display = 'none';
        } else {
            loadMoreBtn.style.display = 'block';
        }
        
        currentDownloadPage = page;
    } catch (error) {
        console.error('Error loading downloads:', error);
    }
}

// Load more downloads
function loadMoreDownloads() {
    loadDownloads(currentDownloadPage + 1);
}

// Modal management
function showUploadModal() {
    document.getElementById('uploadModal').classList.remove('hidden');
}

function hideUploadModal() {
    document.getElementById('uploadModal').classList.add('hidden');
    document.getElementById('uploadForm').reset();
}

function showConfigModal() {
    document.getElementById('configModal').classList.remove('hidden');
    document.getElementById('configForm').reset();
}

function hideConfigModal() {
    document.getElementById('configModal').classList.add('hidden');
    document.getElementById('configForm').reset();
}

// Upload version
document.getElementById('uploadForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = new FormData();
    formData.append('version_name', document.getElementById('versionName').value);
    formData.append('version_code', document.getElementById('versionCode').value);
    formData.append('apk_file', document.getElementById('apkFile').files[0]);
    formData.append('release_notes', document.getElementById('releaseNotes').value);
    
    try {
        const response = await fetch('/api/admin/versions', {
            method: 'POST',
            body: formData
        });
        
        if (response.ok) {
            hideUploadModal();
            loadVersions();
            loadStats();
            alert('Version uploaded successfully!');
        } else {
            const error = await response.json();
            alert('Error: ' + error.error);
        }
    } catch (error) {
        console.error('Error uploading version:', error);
        alert('Error uploading version');
    }
});

// Create/update configuration
document.getElementById('configForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const configData = {
        config_key: document.getElementById('configKey').value,
        config_value: document.getElementById('configValue').value,
        description: document.getElementById('configDescription').value
    };
    
    try {
        const response = await fetch('/api/admin/config', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(configData)
        });
        
        if (response.ok) {
            hideConfigModal();
            loadConfigs();
            loadStats();
            alert('Configuration saved successfully!');
        } else {
            const error = await response.json();
            alert('Error: ' + error.error);
        }
    } catch (error) {
        console.error('Error saving config:', error);
        alert('Error saving configuration');
    }
});

// Toggle version status
async function toggleVersionStatus(versionId, newStatus) {
    try {
        const response = await fetch(`/api/admin/versions/${versionId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ is_active: newStatus })
        });
        
        if (response.ok) {
            loadVersions();
            loadStats();
        } else {
            alert('Error updating version status');
        }
    } catch (error) {
        console.error('Error updating version:', error);
        alert('Error updating version status');
    }
}

// Download version
function downloadVersion(versionId) {
    window.open(`/api/admin/download/${versionId}`, '_blank');
}

// Delete version
async function deleteVersion(versionId) {
    if (!confirm('Are you sure you want to delete this version?')) {
        return;
    }
    
    try {
        const response = await fetch(`/api/admin/versions/${versionId}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            loadVersions();
            loadStats();
            alert('Version deleted successfully!');
        } else {
            alert('Error deleting version');
        }
    } catch (error) {
        console.error('Error deleting version:', error);
        alert('Error deleting version');
    }
}

// Edit configuration
function editConfig(configId, key, value, description) {
    document.getElementById('configKey').value = key;
    document.getElementById('configValue').value = value;
    document.getElementById('configDescription').value = description;
    showConfigModal();
}

// Delete configuration
async function deleteConfig(configId) {
    if (!confirm('Are you sure you want to delete this configuration?')) {
        return;
    }
    
    try {
        const response = await fetch(`/api/admin/config/${configId}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            loadConfigs();
            loadStats();
            alert('Configuration deleted successfully!');
        } else {
            alert('Error deleting configuration');
        }
    } catch (error) {
        console.error('Error deleting config:', error);
        alert('Error deleting configuration');
    }
}

// Utility functions
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleString();
}

// Initialize the dashboard
document.addEventListener('DOMContentLoaded', () => {
    loadStats();
    loadVersions();
});

