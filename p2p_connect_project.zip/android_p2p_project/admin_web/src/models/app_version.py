from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class AppVersion(db.Model):
    __tablename__ = 'app_versions'
    
    id = db.Column(db.Integer, primary_key=True)
    version_name = db.Column(db.String(50), nullable=False)
    version_code = db.Column(db.Integer, nullable=False, unique=True)
    apk_file_path = db.Column(db.String(255), nullable=False)
    apk_file_size = db.Column(db.Integer, nullable=False)
    sha256_hash = db.Column(db.String(64), nullable=False)
    release_notes = db.Column(db.Text)
    is_active = db.Column(db.Boolean, default=True)
    download_count = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'version_name': self.version_name,
            'version_code': self.version_code,
            'apk_file_path': self.apk_file_path,
            'apk_file_size': self.apk_file_size,
            'sha256_hash': self.sha256_hash,
            'release_notes': self.release_notes,
            'is_active': self.is_active,
            'download_count': self.download_count,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class ServerConfig(db.Model):
    __tablename__ = 'server_configs'
    
    id = db.Column(db.Integer, primary_key=True)
    config_key = db.Column(db.String(100), nullable=False, unique=True)
    config_value = db.Column(db.Text, nullable=False)
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'config_key': self.config_key,
            'config_value': self.config_value,
            'description': self.description,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class DownloadLog(db.Model):
    __tablename__ = 'download_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    version_id = db.Column(db.Integer, db.ForeignKey('app_versions.id'), nullable=False)
    ip_address = db.Column(db.String(45), nullable=False)
    user_agent = db.Column(db.Text)
    download_time = db.Column(db.DateTime, default=datetime.utcnow)
    
    version = db.relationship('AppVersion', backref=db.backref('downloads', lazy=True))
    
    def to_dict(self):
        return {
            'id': self.id,
            'version_id': self.version_id,
            'ip_address': self.ip_address,
            'user_agent': self.user_agent,
            'download_time': self.download_time.isoformat() if self.download_time else None,
            'version': self.version.to_dict() if self.version else None
        }

