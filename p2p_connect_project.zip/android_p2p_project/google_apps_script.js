/**
 * Google Apps Script for P2P Connect Email Collection
 * 
 * Setup Instructions:
 * 1. Create a new Google Sheet
 * 2. Go to Extensions > Apps Script
 * 3. Replace the default code with this script
 * 4. Set up the doPost function as a web app
 * 5. Deploy as web app with execute permissions for "Anyone"
 * 6. Copy the web app URL and use it in your landing page
 */

// Configuration
const SHEET_NAME = 'Email Subscribers';
const API_KEY = 'your-secret-api-key-here'; // Change this to a secure random string

/**
 * Handle POST requests to collect email addresses
 */
function doPost(e) {
  try {
    // Parse the request
    const data = JSON.parse(e.postData.contents);
    
    // Verify API key for security
    if (data.api_key !== API_KEY) {
      return ContentService
        .createTextOutput(JSON.stringify({
          success: false,
          error: 'Invalid API key'
        }))
        .setMimeType(ContentService.MimeType.JSON);
    }
    
    // Validate email
    const email = data.email;
    if (!email || !isValidEmail(email)) {
      return ContentService
        .createTextOutput(JSON.stringify({
          success: false,
          error: 'Invalid email address'
        }))
        .setMimeType(ContentService.MimeType.JSON);
    }
    
    // Get or create the spreadsheet
    const sheet = getOrCreateSheet();
    
    // Check if email already exists
    const existingEmails = sheet.getRange('A:A').getValues().flat();
    if (existingEmails.includes(email)) {
      return ContentService
        .createTextOutput(JSON.stringify({
          success: false,
          error: 'Email already subscribed'
        }))
        .setMimeType(ContentService.MimeType.JSON);
    }
    
    // Add email to sheet
    const timestamp = new Date();
    const userAgent = e.parameter.userAgent || 'Unknown';
    const ipAddress = e.parameter.ipAddress || 'Unknown';
    
    sheet.appendRow([
      email,
      timestamp,
      userAgent,
      ipAddress,
      'Active'
    ]);
    
    // Send confirmation email (optional)
    sendConfirmationEmail(email);
    
    return ContentService
      .createTextOutput(JSON.stringify({
        success: true,
        message: 'Email successfully subscribed'
      }))
      .setMimeType(ContentService.MimeType.JSON);
      
  } catch (error) {
    Logger.log('Error in doPost: ' + error.toString());
    
    return ContentService
      .createTextOutput(JSON.stringify({
        success: false,
        error: 'Internal server error'
      }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

/**
 * Handle GET requests for testing
 */
function doGet(e) {
  return ContentService
    .createTextOutput(JSON.stringify({
      message: 'P2P Connect Email Collection API',
      version: '1.0.0',
      endpoints: {
        'POST /': 'Submit email for subscription'
      }
    }))
    .setMimeType(ContentService.MimeType.JSON);
}

/**
 * Get or create the email collection sheet
 */
function getOrCreateSheet() {
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = spreadsheet.getSheetByName(SHEET_NAME);
  
  if (!sheet) {
    sheet = spreadsheet.insertSheet(SHEET_NAME);
    
    // Add headers
    sheet.getRange('A1:E1').setValues([[
      'Email',
      'Timestamp',
      'User Agent',
      'IP Address',
      'Status'
    ]]);
    
    // Format headers
    const headerRange = sheet.getRange('A1:E1');
    headerRange.setFontWeight('bold');
    headerRange.setBackground('#4285f4');
    headerRange.setFontColor('white');
    
    // Auto-resize columns
    sheet.autoResizeColumns(1, 5);
  }
  
  return sheet;
}

/**
 * Validate email address format
 */
function isValidEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * Send confirmation email to subscriber
 */
function sendConfirmationEmail(email) {
  try {
    const subject = 'Welcome to P2P Connect Updates!';
    const body = `
      Hi there!
      
      Thank you for subscribing to P2P Connect updates. You'll be the first to know about:
      
      • New app versions and features
      • Important security updates
      • Tips and tutorials
      • Special announcements
      
      We respect your privacy and will never spam you. You can unsubscribe at any time.
      
      Best regards,
      The P2P Connect Team
      
      ---
      This is an automated message. Please do not reply to this email.
    `;
    
    MailApp.sendEmail({
      to: email,
      subject: subject,
      body: body
    });
    
  } catch (error) {
    Logger.log('Error sending confirmation email: ' + error.toString());
    // Don't throw error - email collection should still succeed
  }
}

/**
 * Get subscriber statistics (for admin use)
 */
function getSubscriberStats() {
  const sheet = getOrCreateSheet();
  const data = sheet.getDataRange().getValues();
  
  if (data.length <= 1) {
    return {
      total: 0,
      active: 0,
      recent: 0
    };
  }
  
  const subscribers = data.slice(1); // Remove header row
  const now = new Date();
  const oneWeekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
  
  const stats = {
    total: subscribers.length,
    active: subscribers.filter(row => row[4] === 'Active').length,
    recent: subscribers.filter(row => new Date(row[1]) > oneWeekAgo).length
  };
  
  return stats;
}

/**
 * Export subscribers to CSV (for admin use)
 */
function exportSubscribers() {
  const sheet = getOrCreateSheet();
  const data = sheet.getDataRange().getValues();
  
  let csv = '';
  data.forEach(row => {
    csv += row.map(cell => `"${cell}"`).join(',') + '\n';
  });
  
  return csv;
}

/**
 * Unsubscribe email (for admin use or unsubscribe links)
 */
function unsubscribeEmail(email) {
  const sheet = getOrCreateSheet();
  const data = sheet.getDataRange().getValues();
  
  for (let i = 1; i < data.length; i++) {
    if (data[i][0] === email) {
      sheet.getRange(i + 1, 5).setValue('Unsubscribed');
      return true;
    }
  }
  
  return false;
}

