import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Download, Smartphone, Users, Video, Shield, Zap, CheckCircle, Star, Mail } from 'lucide-react'
import './App.css'

function App() {
  const [email, setEmail] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitMessage, setSubmitMessage] = useState('')
  const [latestVersion, setLatestVersion] = useState(null)

  useEffect(() => {
    // Fetch latest version from admin API
    fetchLatestVersion()
  }, [])

  const fetchLatestVersion = async () => {
    try {
      const response = await fetch('/api/admin/versions')
      const versions = await response.json()
      const activeVersions = versions.filter(v => v.is_active)
      if (activeVersions.length > 0) {
        setLatestVersion(activeVersions[0])
      }
    } catch (error) {
      console.error('Error fetching latest version:', error)
    }
  }

  const handleEmailSubmit = async (e) => {
    e.preventDefault()
    if (!email) return

    setIsSubmitting(true)
    try {
      // Here you would integrate with Google Apps Script
      // For now, we'll just simulate the submission
      await new Promise(resolve => setTimeout(resolve, 1000))
      setSubmitMessage('Thank you! We\'ll notify you when new versions are available.')
      setEmail('')
    } catch (error) {
      setSubmitMessage('Error submitting email. Please try again.')
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDownload = () => {
    if (latestVersion) {
      window.open(`/api/admin/download/${latestVersion.id}`, '_blank')
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Header */}
      <header className="container mx-auto px-4 py-6">
        <nav className="flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <Video className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold text-gray-900">P2P Connect</span>
          </div>
          <div className="hidden md:flex space-x-6">
            <a href="#features" className="text-gray-600 hover:text-blue-600 transition-colors">Features</a>
            <a href="#download" className="text-gray-600 hover:text-blue-600 transition-colors">Download</a>
            <a href="#contact" className="text-gray-600 hover:text-blue-600 transition-colors">Contact</a>
          </div>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-16 text-center">
        <div className="max-w-4xl mx-auto">
          <Badge className="mb-4 bg-blue-100 text-blue-800 hover:bg-blue-100">
            🚀 Now Available for Android
          </Badge>
          <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6 leading-tight">
            Connect & Share
            <span className="text-blue-600 block">Anywhere, Anytime</span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Experience seamless peer-to-peer screen sharing, video calls, and remote control. 
            Perfect for teams, classrooms, and personal use.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button 
              size="lg" 
              className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 text-lg"
              onClick={handleDownload}
              disabled={!latestVersion}
            >
              <Download className="w-5 h-5 mr-2" />
              {latestVersion ? `Download v${latestVersion.version_name}` : 'Loading...'}
            </Button>
            <div className="text-sm text-gray-500">
              {latestVersion && (
                <>
                  <div>Version {latestVersion.version_name} • {Math.round(latestVersion.apk_file_size / (1024 * 1024))} MB</div>
                  <div>{latestVersion.download_count} downloads</div>
                </>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="container mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Powerful Features for Every Need
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Whether you're working with a team, teaching a class, or helping a friend, 
            P2P Connect has the tools you need.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-16">
          <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                <Smartphone className="w-6 h-6 text-blue-600" />
              </div>
              <CardTitle>Desk Mode</CardTitle>
              <CardDescription>
                Perfect for one-on-one screen sharing and remote assistance. 
                Simple, secure, and efficient.
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                <Users className="w-6 h-6 text-green-600" />
              </div>
              <CardTitle>Team Mode</CardTitle>
              <CardDescription>
                Collaborate with your team members. Admins can view all screens 
                and manage permissions dynamically.
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                <Video className="w-6 h-6 text-purple-600" />
              </div>
              <CardTitle>Class Mode</CardTitle>
              <CardDescription>
                Designed for educators. Teachers can monitor student screens 
                while maintaining privacy and control.
              </CardDescription>
            </CardHeader>
          </Card>
        </div>

        {/* Additional Features */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="text-center">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Shield className="w-8 h-8 text-blue-600" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Secure & Private</h3>
            <p className="text-sm text-gray-600">End-to-end encryption and OAuth authentication</p>
          </div>

          <div className="text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Zap className="w-8 h-8 text-green-600" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Lightning Fast</h3>
            <p className="text-sm text-gray-600">Optimized WebRTC for minimal latency</p>
          </div>

          <div className="text-center">
            <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-8 h-8 text-purple-600" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Easy to Use</h3>
            <p className="text-sm text-gray-600">Join sessions with a simple link or code</p>
          </div>

          <div className="text-center">
            <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Star className="w-8 h-8 text-orange-600" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Cross-Platform</h3>
            <p className="text-sm text-gray-600">Works seamlessly across all devices</p>
          </div>
        </div>
      </section>

      {/* Download Section */}
      <section id="download" className="bg-gray-50 py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Ready to Get Started?
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Download P2P Connect now and experience the future of screen sharing and collaboration.
          </p>
          
          <Card className="max-w-md mx-auto border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center justify-center">
                <Download className="w-5 h-5 mr-2" />
                Download for Android
              </CardTitle>
              {latestVersion && (
                <CardDescription>
                  Version {latestVersion.version_name} • {Math.round(latestVersion.apk_file_size / (1024 * 1024))} MB
                  <br />
                  SHA256: <code className="text-xs">{latestVersion.sha256_hash.substring(0, 16)}...</code>
                </CardDescription>
              )}
            </CardHeader>
            <CardContent>
              <Button 
                className="w-full bg-blue-600 hover:bg-blue-700 text-white mb-4"
                onClick={handleDownload}
                disabled={!latestVersion}
              >
                <Download className="w-4 h-4 mr-2" />
                Download APK
              </Button>
              <p className="text-xs text-gray-500">
                Compatible with Android 7.0 and above
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="container mx-auto px-4 py-16">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Stay Updated
          </h2>
          <p className="text-gray-600 mb-8">
            Get notified when new versions and features are available.
          </p>
          
          <form onSubmit={handleEmailSubmit} className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
            <Input
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="flex-1"
              required
            />
            <Button 
              type="submit" 
              disabled={isSubmitting}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              <Mail className="w-4 h-4 mr-2" />
              {isSubmitting ? 'Subscribing...' : 'Subscribe'}
            </Button>
          </form>
          
          {submitMessage && (
            <p className="mt-4 text-sm text-green-600">{submitMessage}</p>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer id="contact" className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                  <Video className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-bold">P2P Connect</span>
              </div>
              <p className="text-gray-400">
                Connecting people through seamless screen sharing and collaboration.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Features</h3>
              <ul className="space-y-2 text-gray-400">
                <li>Screen Sharing</li>
                <li>Video Calls</li>
                <li>Remote Control</li>
                <li>Team Collaboration</li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Support</h3>
              <ul className="space-y-2 text-gray-400">
                <li>Documentation</li>
                <li>FAQ</li>
                <li>Contact Us</li>
                <li>Privacy Policy</li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 P2P Connect. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App

