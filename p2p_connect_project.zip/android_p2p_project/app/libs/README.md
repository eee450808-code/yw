# مجلد المكتبات المحلية (Local Libraries)

هذا المجلد يحتوي على جميع المكتبات الخارجية المطلوبة للمشروع بشكل محلي لضمان التوافق مع AIDE PRO.

## المكتبات المطلوبة:

### 1. WebRTC
- **ملف:** `libwebrtc.aar`
- **الوصف:** مكتبة WebRTC الرسمية المُجمعة من المصدر
- **المصدر:** يجب تجميعها من مصدر WebRTC الرسمي
- **الحالة:** ⚠️ مطلوب تجميعها

### 2. Socket.IO Client
- **ملف:** `socket.io-client-2.0.1.jar`
- **الوصف:** عميل Socket.IO للتواصل مع خادم الإشارة
- **المصدر:** https://github.com/socketio/socket.io-client-java
- **الحالة:** ⚠️ مطلوب تحميلها

### 3. Engine.IO Client
- **ملف:** `engine.io-client-2.0.1.jar`
- **الوصف:** مكتبة Engine.IO المطلوبة لـ Socket.IO
- **المصدر:** https://github.com/socketio/engine.io-client-java
- **الحالة:** ⚠️ مطلوب تحميلها

### 4. OkHttp
- **ملف:** `okhttp-4.9.3.jar`
- **الوصف:** مكتبة HTTP client للشبكة
- **المصدر:** https://github.com/square/okhttp
- **الحالة:** ⚠️ مطلوب تحميلها

### 5. Okio
- **ملف:** `okio-2.8.0.jar`
- **الوصف:** مكتبة I/O المطلوبة لـ OkHttp
- **المصدر:** https://github.com/square/okio
- **الحالة:** ⚠️ مطلوب تحميلها

### 6. Gson
- **ملف:** `gson-2.8.9.jar`
- **الوصف:** مكتبة JSON parsing
- **المصدر:** https://github.com/google/gson
- **الحالة:** ⚠️ مطلوب تحميلها

## ملفات .so الأصلية (Native Libraries)

يجب وضع ملفات `.so` في المجلدات التالية:
- `../src/main/jniLibs/arm64-v8a/` - للأجهزة 64-bit ARM
- `../src/main/jniLibs/armeabi-v7a/` - للأجهزة 32-bit ARM

### ملفات .so المطلوبة:
- `libwebrtc.so` - مكتبة WebRTC الأصلية
- أي ملفات .so إضافية مطلوبة من WebRTC

## خطوات التحضير:

1. **تجميع WebRTC:** اتبع الخطوات في `README.md` الرئيسي لتجميع WebRTC من المصدر
2. **تحميل JAR files:** قم بتحميل ملفات JAR المطلوبة من المصادر المذكورة أعلاه
3. **وضع الملفات:** ضع جميع الملفات في المجلدات المناسبة
4. **تحديث build.gradle:** قم بإلغاء التعليق عن السطور المناسبة في `app/build.gradle`

## التحقق من التوافق مع AIDE PRO:

بعد وضع جميع الملفات، تأكد من:
- عدم وجود أي `implementation` يشير إلى repositories خارجية في `build.gradle`
- جميع التبعيات محلية في مجلد `libs`
- ملفات `.so` موضوعة في `jniLibs` بالمجلدات الصحيحة
- البناء يعمل في AIDE PRO بدون اتصال بالإنترنت

