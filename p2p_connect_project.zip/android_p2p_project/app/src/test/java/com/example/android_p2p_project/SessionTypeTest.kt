package com.example.android_p2p_project

import org.junit.Test
import org.junit.Assert.*

/**
 * Unit tests for SessionType and UserRole enums
 */
class SessionTypeTest {

    @Test
    fun testSessionType_allValuesPresent() {
        val sessionTypes = SessionType.values()
        
        assertEquals("Should have exactly 3 session types", 3, sessionTypes.size)
        assertTrue("Should contain DESK", sessionTypes.contains(SessionType.DESK))
        assertTrue("Should contain TEAM", sessionTypes.contains(SessionType.TEAM))
        assertTrue("Should contain CLASS", sessionTypes.contains(SessionType.CLASS))
    }

    @Test
    fun testSessionType_stringValues() {
        assertEquals("DESK string value should be 'desk'", "desk", SessionType.DESK.value)
        assertEquals("TEAM string value should be 'team'", "team", SessionType.TEAM.value)
        assertEquals("CLASS string value should be 'class'", "class", SessionType.CLASS.value)
    }

    @Test
    fun testSessionType_fromString_validValues() {
        assertEquals("Should parse 'desk' correctly", SessionType.DESK, SessionType.fromString("desk"))
        assertEquals("Should parse 'team' correctly", SessionType.TEAM, SessionType.fromString("team"))
        assertEquals("Should parse 'class' correctly", SessionType.CLASS, SessionType.fromString("class"))
    }

    @Test
    fun testSessionType_fromString_caseInsensitive() {
        assertEquals("Should parse 'DESK' correctly", SessionType.DESK, SessionType.fromString("DESK"))
        assertEquals("Should parse 'Team' correctly", SessionType.TEAM, SessionType.fromString("Team"))
        assertEquals("Should parse 'CLASS' correctly", SessionType.CLASS, SessionType.fromString("CLASS"))
    }

    @Test
    fun testSessionType_fromString_invalidValue() {
        assertNull("Should return null for invalid value", SessionType.fromString("invalid"))
        assertNull("Should return null for empty string", SessionType.fromString(""))
        assertNull("Should return null for null", SessionType.fromString(null))
    }

    @Test
    fun testUserRole_allValuesPresent() {
        val userRoles = UserRole.values()
        
        assertEquals("Should have exactly 4 user roles", 4, userRoles.size)
        assertTrue("Should contain ADMIN", userRoles.contains(UserRole.ADMIN))
        assertTrue("Should contain MEMBER", userRoles.contains(UserRole.MEMBER))
        assertTrue("Should contain TEACHER", userRoles.contains(UserRole.TEACHER))
        assertTrue("Should contain STUDENT", userRoles.contains(UserRole.STUDENT))
    }

    @Test
    fun testUserRole_stringValues() {
        assertEquals("ADMIN string value should be 'admin'", "admin", UserRole.ADMIN.value)
        assertEquals("MEMBER string value should be 'member'", "member", UserRole.MEMBER.value)
        assertEquals("TEACHER string value should be 'teacher'", "teacher", UserRole.TEACHER.value)
        assertEquals("STUDENT string value should be 'student'", "student", UserRole.STUDENT.value)
    }

    @Test
    fun testUserRole_fromString_validValues() {
        assertEquals("Should parse 'admin' correctly", UserRole.ADMIN, UserRole.fromString("admin"))
        assertEquals("Should parse 'member' correctly", UserRole.MEMBER, UserRole.fromString("member"))
        assertEquals("Should parse 'teacher' correctly", UserRole.TEACHER, UserRole.fromString("teacher"))
        assertEquals("Should parse 'student' correctly", UserRole.STUDENT, UserRole.fromString("student"))
    }

    @Test
    fun testUserRole_fromString_caseInsensitive() {
        assertEquals("Should parse 'ADMIN' correctly", UserRole.ADMIN, UserRole.fromString("ADMIN"))
        assertEquals("Should parse 'Member' correctly", UserRole.MEMBER, UserRole.fromString("Member"))
        assertEquals("Should parse 'TEACHER' correctly", UserRole.TEACHER, UserRole.fromString("TEACHER"))
        assertEquals("Should parse 'Student' correctly", UserRole.STUDENT, UserRole.fromString("Student"))
    }

    @Test
    fun testUserRole_fromString_invalidValue() {
        assertNull("Should return null for invalid value", UserRole.fromString("invalid"))
        assertNull("Should return null for empty string", UserRole.fromString(""))
        assertNull("Should return null for null", UserRole.fromString(null))
    }

    @Test
    fun testSessionPermissions_deskMode() {
        val permissions = SessionPermissions.getPermissions(SessionType.DESK, UserRole.ADMIN)
        
        assertTrue("Admin should be able to share screen in desk mode", permissions.canShareScreen)
        assertTrue("Admin should be able to request control in desk mode", permissions.canRequestControl)
        assertTrue("Admin should be able to view others in desk mode", permissions.canViewOthers)
        assertTrue("Admin should be able to manage session in desk mode", permissions.canManageSession)
    }

    @Test
    fun testSessionPermissions_teamModeAdmin() {
        val permissions = SessionPermissions.getPermissions(SessionType.TEAM, UserRole.ADMIN)
        
        assertTrue("Team admin should be able to share screen", permissions.canShareScreen)
        assertTrue("Team admin should be able to request control", permissions.canRequestControl)
        assertTrue("Team admin should be able to view others", permissions.canViewOthers)
        assertTrue("Team admin should be able to manage session", permissions.canManageSession)
    }

    @Test
    fun testSessionPermissions_teamModeMember() {
        val permissions = SessionPermissions.getPermissions(SessionType.TEAM, UserRole.MEMBER)
        
        assertTrue("Team member should be able to share screen", permissions.canShareScreen)
        assertTrue("Team member should be able to request control", permissions.canRequestControl)
        assertFalse("Team member should not be able to view others by default", permissions.canViewOthers)
        assertFalse("Team member should not be able to manage session", permissions.canManageSession)
    }

    @Test
    fun testSessionPermissions_classModeTeacher() {
        val permissions = SessionPermissions.getPermissions(SessionType.CLASS, UserRole.TEACHER)
        
        assertTrue("Teacher should be able to share screen", permissions.canShareScreen)
        assertTrue("Teacher should be able to request control", permissions.canRequestControl)
        assertTrue("Teacher should be able to view others", permissions.canViewOthers)
        assertTrue("Teacher should be able to manage session", permissions.canManageSession)
    }

    @Test
    fun testSessionPermissions_classModeStudent() {
        val permissions = SessionPermissions.getPermissions(SessionType.CLASS, UserRole.STUDENT)
        
        assertTrue("Student should be able to share screen", permissions.canShareScreen)
        assertFalse("Student should not be able to request control by default", permissions.canRequestControl)
        assertFalse("Student should not be able to view others", permissions.canViewOthers)
        assertFalse("Student should not be able to manage session", permissions.canManageSession)
    }

    @Test
    fun testSessionPermissions_invalidCombinations() {
        // Test invalid role for session type
        val permissions1 = SessionPermissions.getPermissions(SessionType.CLASS, UserRole.ADMIN)
        assertFalse("Admin role should not have permissions in class mode", permissions1.canManageSession)
        
        val permissions2 = SessionPermissions.getPermissions(SessionType.TEAM, UserRole.TEACHER)
        assertFalse("Teacher role should not have special permissions in team mode", permissions2.canManageSession)
    }

    @Test
    fun testSessionPermissions_consistency() {
        // Test that permissions are consistent
        val deskAdmin = SessionPermissions.getPermissions(SessionType.DESK, UserRole.ADMIN)
        val deskMember = SessionPermissions.getPermissions(SessionType.DESK, UserRole.MEMBER)
        
        // In desk mode, both should have similar permissions
        assertEquals("Desk mode permissions should be consistent", 
                    deskAdmin.canShareScreen, deskMember.canShareScreen)
    }

    @Test
    fun testSessionType_enumOrdinal() {
        // Test that enum ordinals are as expected (for serialization consistency)
        assertEquals("DESK should be ordinal 0", 0, SessionType.DESK.ordinal)
        assertEquals("TEAM should be ordinal 1", 1, SessionType.TEAM.ordinal)
        assertEquals("CLASS should be ordinal 2", 2, SessionType.CLASS.ordinal)
    }

    @Test
    fun testUserRole_enumOrdinal() {
        // Test that enum ordinals are as expected (for serialization consistency)
        assertEquals("ADMIN should be ordinal 0", 0, UserRole.ADMIN.ordinal)
        assertEquals("MEMBER should be ordinal 1", 1, UserRole.MEMBER.ordinal)
        assertEquals("TEACHER should be ordinal 2", 2, UserRole.TEACHER.ordinal)
        assertEquals("STUDENT should be ordinal 3", 3, UserRole.STUDENT.ordinal)
    }
}

