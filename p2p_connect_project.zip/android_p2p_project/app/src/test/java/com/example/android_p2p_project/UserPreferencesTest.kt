package com.example.android_p2p_project

import android.content.Context
import android.content.SharedPreferences
import org.junit.Test
import org.junit.Assert.*
import org.junit.Before
import org.mockito.Mock
import org.mockito.Mockito.*
import org.mockito.MockitoAnnotations

/**
 * Unit tests for UserPreferences class
 */
class UserPreferencesTest {

    @Mock
    private lateinit var mockContext: Context

    @Mock
    private lateinit var mockSharedPreferences: SharedPreferences

    @Mock
    private lateinit var mockEditor: SharedPreferences.Editor

    @Before
    fun setUp() {
        MockitoAnnotations.openMocks(this)
        
        // Setup SharedPreferences mock
        `when`(mockContext.getSharedPreferences(anyString(), anyInt()))
            .thenReturn(mockSharedPreferences)
        `when`(mockSharedPreferences.edit()).thenReturn(mockEditor)
        `when`(mockEditor.putString(anyString(), anyString())).thenReturn(mockEditor)
        `when`(mockEditor.remove(anyString())).thenReturn(mockEditor)
    }

    @Test
    fun testSaveUserName_callsCorrectMethods() {
        val testUserName = "John Doe"

        UserPreferences.saveUserName(mockContext, testUserName)

        // Verify correct SharedPreferences calls
        verify(mockContext).getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
        verify(mockSharedPreferences).edit()
        verify(mockEditor).putString("user_name", testUserName)
        verify(mockEditor).apply()
    }

    @Test
    fun testGetUserName_returnsCorrectValue() {
        val testUserName = "Jane Smith"
        `when`(mockSharedPreferences.getString("user_name", null))
            .thenReturn(testUserName)

        val result = UserPreferences.getUserName(mockContext)

        assertEquals("Should return correct user name", testUserName, result)
        verify(mockSharedPreferences).getString("user_name", null)
    }

    @Test
    fun testGetUserName_returnsNullWhenNotSet() {
        `when`(mockSharedPreferences.getString("user_name", null))
            .thenReturn(null)

        val result = UserPreferences.getUserName(mockContext)

        assertNull("Should return null when user name not set", result)
    }

    @Test
    fun testSaveUserId_callsCorrectMethods() {
        val testUserId = "user-123-456-789"

        UserPreferences.saveUserId(mockContext, testUserId)

        verify(mockContext).getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
        verify(mockSharedPreferences).edit()
        verify(mockEditor).putString("user_id", testUserId)
        verify(mockEditor).apply()
    }

    @Test
    fun testGetUserId_returnsCorrectValue() {
        val testUserId = "user-987-654-321"
        `when`(mockSharedPreferences.getString("user_id", null))
            .thenReturn(testUserId)

        val result = UserPreferences.getUserId(mockContext)

        assertEquals("Should return correct user ID", testUserId, result)
        verify(mockSharedPreferences).getString("user_id", null)
    }

    @Test
    fun testGetUserId_returnsNullWhenNotSet() {
        `when`(mockSharedPreferences.getString("user_id", null))
            .thenReturn(null)

        val result = UserPreferences.getUserId(mockContext)

        assertNull("Should return null when user ID not set", result)
    }

    @Test
    fun testSaveAccessToken_callsCorrectMethods() {
        val testToken = "access_token_123456789"

        UserPreferences.saveAccessToken(mockContext, testToken)

        verify(mockContext).getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
        verify(mockSharedPreferences).edit()
        verify(mockEditor).putString("access_token", testToken)
        verify(mockEditor).apply()
    }

    @Test
    fun testGetAccessToken_returnsCorrectValue() {
        val testToken = "access_token_987654321"
        `when`(mockSharedPreferences.getString("access_token", null))
            .thenReturn(testToken)

        val result = UserPreferences.getAccessToken(mockContext)

        assertEquals("Should return correct access token", testToken, result)
        verify(mockSharedPreferences).getString("access_token", null)
    }

    @Test
    fun testGetAccessToken_returnsNullWhenNotSet() {
        `when`(mockSharedPreferences.getString("access_token", null))
            .thenReturn(null)

        val result = UserPreferences.getAccessToken(mockContext)

        assertNull("Should return null when access token not set", result)
    }

    @Test
    fun testClearUserData_removesAllUserData() {
        UserPreferences.clearUserData(mockContext)

        verify(mockContext).getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
        verify(mockSharedPreferences).edit()
        verify(mockEditor).remove("user_name")
        verify(mockEditor).remove("user_id")
        verify(mockEditor).remove("access_token")
        verify(mockEditor).apply()
    }

    @Test
    fun testSaveServerUrl_callsCorrectMethods() {
        val testUrl = "wss://example.com:3000"

        UserPreferences.saveServerUrl(mockContext, testUrl)

        verify(mockContext).getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
        verify(mockSharedPreferences).edit()
        verify(mockEditor).putString("server_url", testUrl)
        verify(mockEditor).apply()
    }

    @Test
    fun testGetServerUrl_returnsCorrectValue() {
        val testUrl = "wss://test.example.com:3000"
        `when`(mockSharedPreferences.getString("server_url", "ws://localhost:3000"))
            .thenReturn(testUrl)

        val result = UserPreferences.getServerUrl(mockContext)

        assertEquals("Should return correct server URL", testUrl, result)
        verify(mockSharedPreferences).getString("server_url", "ws://localhost:3000")
    }

    @Test
    fun testGetServerUrl_returnsDefaultWhenNotSet() {
        val defaultUrl = "ws://localhost:3000"
        `when`(mockSharedPreferences.getString("server_url", defaultUrl))
            .thenReturn(defaultUrl)

        val result = UserPreferences.getServerUrl(mockContext)

        assertEquals("Should return default server URL when not set", defaultUrl, result)
    }

    @Test
    fun testMultipleOperations_workCorrectly() {
        val userName = "Test User"
        val userId = "test-user-id"
        val accessToken = "test-token"
        val serverUrl = "wss://test.com:3000"

        // Save all data
        UserPreferences.saveUserName(mockContext, userName)
        UserPreferences.saveUserId(mockContext, userId)
        UserPreferences.saveAccessToken(mockContext, accessToken)
        UserPreferences.saveServerUrl(mockContext, serverUrl)

        // Verify all save operations
        verify(mockEditor, times(4)).apply()
        verify(mockEditor).putString("user_name", userName)
        verify(mockEditor).putString("user_id", userId)
        verify(mockEditor).putString("access_token", accessToken)
        verify(mockEditor).putString("server_url", serverUrl)
    }

    @Test
    fun testEmptyStringHandling() {
        val emptyString = ""

        UserPreferences.saveUserName(mockContext, emptyString)

        verify(mockEditor).putString("user_name", emptyString)
        verify(mockEditor).apply()
    }

    @Test
    fun testNullStringHandling() {
        // Test saving null (should be handled gracefully)
        UserPreferences.saveUserName(mockContext, null)

        verify(mockEditor).putString("user_name", null)
        verify(mockEditor).apply()
    }
}

