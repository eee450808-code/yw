package com.example.android_p2p_project

import android.content.Context
import android.provider.Settings
import org.junit.Test
import org.junit.Assert.*
import org.junit.Before
import org.mockito.Mock
import org.mockito.Mockito.*
import org.mockito.MockitoAnnotations
import java.util.UUID

/**
 * Unit tests for DeviceUtils class
 */
class DeviceUtilsTest {

    @Mock
    private lateinit var mockContext: Context

    @Before
    fun setUp() {
        MockitoAnnotations.openMocks(this)
    }

    @Test
    fun testGetDeviceId_returnsValidUUID() {
        // Mock Android ID
        val mockAndroidId = "test_android_id_123"
        `when`(Settings.Secure.getString(any(), eq(Settings.Secure.ANDROID_ID)))
            .thenReturn(mockAndroidId)

        val deviceId = DeviceUtils.getDeviceId(mockContext)

        // Verify device ID is not null and not empty
        assertNotNull("Device ID should not be null", deviceId)
        assertTrue("Device ID should not be empty", deviceId.isNotEmpty())
        
        // Verify it's a valid UUID format (36 characters with hyphens)
        assertEquals("Device ID should be 36 characters long", 36, deviceId.length)
        assertTrue("Device ID should contain hyphens", deviceId.contains("-"))
    }

    @Test
    fun testGetDeviceId_consistentResults() {
        // Mock Android ID
        val mockAndroidId = "consistent_android_id"
        `when`(Settings.Secure.getString(any(), eq(Settings.Secure.ANDROID_ID)))
            .thenReturn(mockAndroidId)

        val deviceId1 = DeviceUtils.getDeviceId(mockContext)
        val deviceId2 = DeviceUtils.getDeviceId(mockContext)

        // Device ID should be consistent for the same Android ID
        assertEquals("Device ID should be consistent", deviceId1, deviceId2)
    }

    @Test
    fun testGetDeviceId_nullAndroidId_generatesFallback() {
        // Mock null Android ID
        `when`(Settings.Secure.getString(any(), eq(Settings.Secure.ANDROID_ID)))
            .thenReturn(null)

        val deviceId = DeviceUtils.getDeviceId(mockContext)

        // Should still return a valid device ID
        assertNotNull("Device ID should not be null even with null Android ID", deviceId)
        assertTrue("Device ID should not be empty", deviceId.isNotEmpty())
        assertEquals("Device ID should be 36 characters long", 36, deviceId.length)
    }

    @Test
    fun testGetDeviceId_emptyAndroidId_generatesFallback() {
        // Mock empty Android ID
        `when`(Settings.Secure.getString(any(), eq(Settings.Secure.ANDROID_ID)))
            .thenReturn("")

        val deviceId = DeviceUtils.getDeviceId(mockContext)

        // Should still return a valid device ID
        assertNotNull("Device ID should not be null even with empty Android ID", deviceId)
        assertTrue("Device ID should not be empty", deviceId.isNotEmpty())
        assertEquals("Device ID should be 36 characters long", 36, deviceId.length)
    }

    @Test
    fun testGenerateUserId_returnsValidUUID() {
        val userId = DeviceUtils.generateUserId()

        // Verify user ID is a valid UUID
        assertNotNull("User ID should not be null", userId)
        assertEquals("User ID should be 36 characters long", 36, userId.length)
        assertTrue("User ID should contain hyphens", userId.contains("-"))
        
        // Verify it can be parsed as UUID
        try {
            UUID.fromString(userId)
        } catch (e: IllegalArgumentException) {
            fail("User ID should be a valid UUID format")
        }
    }

    @Test
    fun testGenerateUserId_uniqueResults() {
        val userId1 = DeviceUtils.generateUserId()
        val userId2 = DeviceUtils.generateUserId()

        // Each call should generate a unique user ID
        assertNotEquals("User IDs should be unique", userId1, userId2)
    }

    @Test
    fun testGenerateUserId_multipleCallsAllUnique() {
        val userIds = mutableSetOf<String>()
        val iterations = 100

        // Generate multiple user IDs
        repeat(iterations) {
            val userId = DeviceUtils.generateUserId()
            userIds.add(userId)
        }

        // All should be unique
        assertEquals("All generated user IDs should be unique", iterations, userIds.size)
    }

    @Test
    fun testDeviceIdFormat_matchesExpectedPattern() {
        val mockAndroidId = "test_device_123"
        `when`(Settings.Secure.getString(any(), eq(Settings.Secure.ANDROID_ID)))
            .thenReturn(mockAndroidId)

        val deviceId = DeviceUtils.getDeviceId(mockContext)

        // Verify UUID format: 8-4-4-4-12 characters
        val uuidPattern = Regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")
        assertTrue("Device ID should match UUID pattern", uuidPattern.matches(deviceId))
    }

    @Test
    fun testUserIdFormat_matchesExpectedPattern() {
        val userId = DeviceUtils.generateUserId()

        // Verify UUID format: 8-4-4-4-12 characters
        val uuidPattern = Regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")
        assertTrue("User ID should match UUID pattern", uuidPattern.matches(userId))
    }
}

