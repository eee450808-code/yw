package com.example.android_p2p_project

import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.util.Log
import org.webrtc.*
import org.webrtc.audio.AudioDeviceModule
import org.webrtc.audio.JavaAudioDeviceModule
import java.util.*

class WebRTCManager(private val context: Context) {
    
    companion object {
        private const val TAG = "WebRTCManager"
        private const val LOCAL_STREAM_ID = "local_stream"
        private const val VIDEO_TRACK_ID = "video_track"
        private const val AUDIO_TRACK_ID = "audio_track"
        private const val SCREEN_SHARE_TRACK_ID = "screen_share_track"
    }
    
    private var peerConnectionFactory: PeerConnectionFactory? = null
    private var localPeerConnection: PeerConnection? = null
    private var remotePeerConnections = mutableMapOf<String, PeerConnection>()
    
    private var localVideoTrack: VideoTrack? = null
    private var localAudioTrack: AudioTrack? = null
    private var screenShareVideoTrack: VideoTrack? = null
    
    private var videoCapturer: VideoCapturer? = null
    private var screenCapturer: ScreenCapturerAndroid? = null
    private var mediaProjection: MediaProjection? = null
    
    private var localVideoSource: VideoSource? = null
    private var localAudioSource: AudioSource? = null
    private var screenVideoSource: VideoSource? = null
    
    private var signalingClient: SignalingClient? = null
    private var isAudioMuted = false
    private var isScreenSharing = false
    
    // ICE servers configuration
    private val iceServers = listOf(
        PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer()
        // Add TURN servers here when available
    )
    
    init {
        initializePeerConnectionFactory()
    }
    
    private fun initializePeerConnectionFactory() {
        val options = PeerConnectionFactory.InitializationOptions.builder(context)
            .setEnableInternalTracer(true)
            .createInitializationOptions()
        
        PeerConnectionFactory.initialize(options)
        
        val audioDeviceModule = JavaAudioDeviceModule.builder(context)
            .createAudioDeviceModule()
        
        peerConnectionFactory = PeerConnectionFactory.builder()
            .setAudioDeviceModule(audioDeviceModule)
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(
                EglBase.create().eglBaseContext,
                true,
                true
            ))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(EglBase.create().eglBaseContext))
            .createPeerConnectionFactory()
        
        Log.d(TAG, "PeerConnectionFactory initialized")
    }
    
    fun setSignalingClient(signalingClient: SignalingClient) {
        this.signalingClient = signalingClient
    }
    
    fun createLocalPeerConnection(deviceId: String): PeerConnection? {
        val rtcConfig = PeerConnection.RTCConfiguration(iceServers).apply {
            bundlePolicy = PeerConnection.BundlePolicy.MAXBUNDLE
            rtcpMuxPolicy = PeerConnection.RtcpMuxPolicy.REQUIRE
            tcpCandidatePolicy = PeerConnection.TcpCandidatePolicy.DISABLED
            candidateNetworkPolicy = PeerConnection.CandidateNetworkPolicy.ALL
            keyType = PeerConnection.KeyType.ECDSA
        }
        
        val observer = object : PeerConnection.Observer {
            override fun onSignalingChange(state: PeerConnection.SignalingState?) {
                Log.d(TAG, "Local PC Signaling state: $state")
            }
            
            override fun onIceConnectionChange(state: PeerConnection.IceConnectionState?) {
                Log.d(TAG, "Local PC ICE connection state: $state")
            }
            
            override fun onIceGatheringChange(state: PeerConnection.IceGatheringState?) {
                Log.d(TAG, "Local PC ICE gathering state: $state")
            }
            
            override fun onIceCandidate(candidate: IceCandidate?) {
                candidate?.let {
                    signalingClient?.sendIceCandidate(it, deviceId)
                }
            }
            
            override fun onAddStream(stream: MediaStream?) {
                Log.d(TAG, "Local PC: Stream added")
            }
            
            override fun onRemoveStream(stream: MediaStream?) {
                Log.d(TAG, "Local PC: Stream removed")
            }
            
            override fun onDataChannel(dataChannel: DataChannel?) {
                Log.d(TAG, "Local PC: Data channel created")
            }
            
            override fun onRenegotiationNeeded() {
                Log.d(TAG, "Local PC: Renegotiation needed")
            }
            
            override fun onAddTrack(receiver: RtpReceiver?, streams: Array<out MediaStream>?) {
                Log.d(TAG, "Local PC: Track added")
            }
        }
        
        localPeerConnection = peerConnectionFactory?.createPeerConnection(rtcConfig, observer)
        
        // Add local stream
        createLocalMediaStream()?.let { stream ->
            localPeerConnection?.addStream(stream)
        }
        
        return localPeerConnection
    }
    
    fun createRemotePeerConnection(deviceId: String): PeerConnection? {
        val rtcConfig = PeerConnection.RTCConfiguration(iceServers).apply {
            bundlePolicy = PeerConnection.BundlePolicy.MAXBUNDLE
            rtcpMuxPolicy = PeerConnection.RtcpMuxPolicy.REQUIRE
            tcpCandidatePolicy = PeerConnection.TcpCandidatePolicy.DISABLED
            candidateNetworkPolicy = PeerConnection.CandidateNetworkPolicy.ALL
            keyType = PeerConnection.KeyType.ECDSA
        }
        
        val observer = object : PeerConnection.Observer {
            override fun onSignalingChange(state: PeerConnection.SignalingState?) {
                Log.d(TAG, "Remote PC ($deviceId) Signaling state: $state")
            }
            
            override fun onIceConnectionChange(state: PeerConnection.IceConnectionState?) {
                Log.d(TAG, "Remote PC ($deviceId) ICE connection state: $state")
            }
            
            override fun onIceGatheringChange(state: PeerConnection.IceGatheringState?) {
                Log.d(TAG, "Remote PC ($deviceId) ICE gathering state: $state")
            }
            
            override fun onIceCandidate(candidate: IceCandidate?) {
                candidate?.let {
                    signalingClient?.sendIceCandidate(it, deviceId)
                }
            }
            
            override fun onAddStream(stream: MediaStream?) {
                Log.d(TAG, "Remote PC ($deviceId): Stream added")
                // Handle remote stream
            }
            
            override fun onRemoveStream(stream: MediaStream?) {
                Log.d(TAG, "Remote PC ($deviceId): Stream removed")
            }
            
            override fun onDataChannel(dataChannel: DataChannel?) {
                Log.d(TAG, "Remote PC ($deviceId): Data channel created")
            }
            
            override fun onRenegotiationNeeded() {
                Log.d(TAG, "Remote PC ($deviceId): Renegotiation needed")
            }
            
            override fun onAddTrack(receiver: RtpReceiver?, streams: Array<out MediaStream>?) {
                Log.d(TAG, "Remote PC ($deviceId): Track added")
            }
        }
        
        val peerConnection = peerConnectionFactory?.createPeerConnection(rtcConfig, observer)
        remotePeerConnections[deviceId] = peerConnection!!
        
        return peerConnection
    }
    
    fun removeRemotePeerConnection(deviceId: String) {
        remotePeerConnections[deviceId]?.close()
        remotePeerConnections.remove(deviceId)
        Log.d(TAG, "Removed remote peer connection for device: $deviceId")
    }
    
    private fun createLocalMediaStream(): MediaStream? {
        val stream = peerConnectionFactory?.createLocalMediaStream(LOCAL_STREAM_ID)
        
        // Create audio track
        localAudioSource = peerConnectionFactory?.createAudioSource(MediaConstraints())
        localAudioTrack = peerConnectionFactory?.createAudioTrack(AUDIO_TRACK_ID, localAudioSource)
        stream?.addTrack(localAudioTrack)
        
        // Create video track (camera)
        createCameraVideoTrack()?.let { videoTrack ->
            stream?.addTrack(videoTrack)
        }
        
        return stream
    }
    
    private fun createCameraVideoTrack(): VideoTrack? {
        val surfaceTextureHelper = SurfaceTextureHelper.create("CameraThread", EglBase.create().eglBaseContext)
        
        videoCapturer = createCameraCapturer()
        localVideoSource = peerConnectionFactory?.createVideoSource(videoCapturer?.isScreencast ?: false)
        
        videoCapturer?.initialize(surfaceTextureHelper, context, localVideoSource?.capturerObserver)
        videoCapturer?.startCapture(1280, 720, 30)
        
        localVideoTrack = peerConnectionFactory?.createVideoTrack(VIDEO_TRACK_ID, localVideoSource)
        
        return localVideoTrack
    }
    
    private fun createCameraCapturer(): VideoCapturer? {
        val enumerator = Camera2Enumerator(context)
        
        // Try to find front camera first
        for (deviceName in enumerator.deviceNames) {
            if (enumerator.isFrontFacing(deviceName)) {
                val capturer = enumerator.createCapturer(deviceName, null)
                if (capturer != null) {
                    return capturer
                }
            }
        }
        
        // If no front camera, try back camera
        for (deviceName in enumerator.deviceNames) {
            if (!enumerator.isFrontFacing(deviceName)) {
                val capturer = enumerator.createCapturer(deviceName, null)
                if (capturer != null) {
                    return capturer
                }
            }
        }
        
        return null
    }
    
    fun startScreenShare(resultCode: Int, data: Intent) {
        if (isScreenSharing) {
            Log.w(TAG, "Screen sharing already active")
            return
        }

        // Check permissions before starting screen share
        val currentSessionType = signalingClient?.currentSessionType
        val currentUserRole = signalingClient?.currentUserRole

        if (currentSessionType != null && currentUserRole != null &&
            !SessionPermissions.canShareScreen(currentSessionType, currentUserRole)) {
            Log.w(TAG, "User does not have permission to share screen in this session type/role.")
            return
        }
        
        val mediaProjectionManager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = mediaProjectionManager.getMediaProjection(resultCode, data)
        
        val surfaceTextureHelper = SurfaceTextureHelper.create("ScreenShareThread", EglBase.create().eglBaseContext)
        
        screenCapturer = ScreenCapturerAndroid(data, object : MediaProjection.Callback() {
            override fun onStop() {
                Log.d(TAG, "Screen capture stopped")
                stopScreenShare()
            }
        })
        
        screenVideoSource = peerConnectionFactory?.createVideoSource(true)
        screenCapturer?.initialize(surfaceTextureHelper, context, screenVideoSource?.capturerObserver)
        screenCapturer?.startCapture(1280, 720, 15)
        
        screenShareVideoTrack = peerConnectionFactory?.createVideoTrack(SCREEN_SHARE_TRACK_ID, screenVideoSource)
        
        // Add screen share track to all peer connections
        localPeerConnection?.addTrack(screenShareVideoTrack)
        remotePeerConnections.values.forEach { pc ->
            pc.addTrack(screenShareVideoTrack)
        }
        
        isScreenSharing = true
        signalingClient?.notifyScreenShareStarted()
        
        Log.d(TAG, "Screen sharing started")
    }
    
    fun stopScreenShare() {
        if (!isScreenSharing) {
            return
        }
        
        screenCapturer?.stopCapture()
        screenCapturer?.dispose()
        screenCapturer = null
        
        screenShareVideoTrack?.dispose()
        screenShareVideoTrack = null
        
        screenVideoSource?.dispose()
        screenVideoSource = null
        
        mediaProjection?.stop()
        mediaProjection = null
        
        isScreenSharing = false
        signalingClient?.notifyScreenShareStopped()
        
        Log.d(TAG, "Screen sharing stopped")
    }
    
    fun toggleAudioMute(): Boolean {
        localAudioTrack?.setEnabled(!isAudioMuted)
        isAudioMuted = !isAudioMuted
        Log.d(TAG, "Audio muted: $isAudioMuted")
        return isAudioMuted
    }
    
    fun createOffer(deviceId: String, callback: (SessionDescription?) -> Unit) {
        val peerConnection = remotePeerConnections[deviceId] ?: localPeerConnection
        
        val constraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "true"))
        }
        
        peerConnection?.createOffer(object : SdpObserver {
            override fun onCreateSuccess(sessionDescription: SessionDescription?) {
                peerConnection.setLocalDescription(object : SdpObserver {
                    override fun onSetSuccess() {
                        callback(sessionDescription)
                    }
                    override fun onSetFailure(error: String?) {
                        Log.e(TAG, "Failed to set local description: $error")
                        callback(null)
                    }
                    override fun onCreateSuccess(p0: SessionDescription?) {}
                    override fun onCreateFailure(p0: String?) {}
                }, sessionDescription)
            }
            
            override fun onCreateFailure(error: String?) {
                Log.e(TAG, "Failed to create offer: $error")
                callback(null)
            }
            
            override fun onSetSuccess() {}
            override fun onSetFailure(error: String?) {}
        }, constraints)
    }
    
    fun createAnswer(deviceId: String, callback: (SessionDescription?) -> Unit) {
        val peerConnection = remotePeerConnections[deviceId] ?: localPeerConnection
        
        val constraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "true"))
        }
        
        peerConnection?.createAnswer(object : SdpObserver {
            override fun onCreateSuccess(sessionDescription: SessionDescription?) {
                peerConnection.setLocalDescription(object : SdpObserver {
                    override fun onSetSuccess() {
                        callback(sessionDescription)
                    }
                    override fun onSetFailure(error: String?) {
                        Log.e(TAG, "Failed to set local description: $error")
                        callback(null)
                    }
                    override fun onCreateSuccess(p0: SessionDescription?) {}
                    override fun onCreateFailure(p0: String?) {}
                }, sessionDescription)
            }
            
            override fun onCreateFailure(error: String?) {
                Log.e(TAG, "Failed to create answer: $error")
                callback(null)
            }
            
            override fun onSetSuccess() {}
            override fun onSetFailure(error: String?) {}
        }, constraints)
    }
    
    fun setRemoteDescription(deviceId: String, sessionDescription: SessionDescription, callback: () -> Unit) {
        val peerConnection = remotePeerConnections[deviceId] ?: localPeerConnection
        
        peerConnection?.setRemoteDescription(object : SdpObserver {
            override fun onSetSuccess() {
                callback()
            }
            
            override fun onSetFailure(error: String?) {
                Log.e(TAG, "Failed to set remote description: $error")
            }
            
            override fun onCreateSuccess(p0: SessionDescription?) {}
            override fun onCreateFailure(p0: String?) {}
        }, sessionDescription)
    }
    
    fun addIceCandidate(deviceId: String, iceCandidate: IceCandidate) {
        val peerConnection = remotePeerConnections[deviceId] ?: localPeerConnection
        peerConnection?.addIceCandidate(iceCandidate)
    }
    
    fun cleanup() {
        stopScreenShare()
        
        videoCapturer?.stopCapture()
        videoCapturer?.dispose()
        
        localVideoTrack?.dispose()
        localAudioTrack?.dispose()
        
        localVideoSource?.dispose()
        localAudioSource?.dispose()
        
        localPeerConnection?.close()
        localPeerConnection = null
        
        remotePeerConnections.values.forEach { it.close() }
        remotePeerConnections.clear()
        
        peerConnectionFactory?.dispose()
        peerConnectionFactory = null
    }
}


