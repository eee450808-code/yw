package com.example.android_p2p_project

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.browser.customtabs.CustomTabsIntent
import net.openid.appauth.*
import net.openid.appauth.browser.BrowserAllowList
import net.openid.appauth.browser.BrowserBlacklist
import net.openid.appauth.browser.VersionRange
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class AuthManager(private val context: Context) {

    private val authService: AuthorizationService = AuthorizationService(context)
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()

    companion object {
        // TODO: Replace with your actual OAuth 2.0 configuration
        const val AUTH_ENDPOINT = "https://accounts.google.com/o/oauth2/v2/auth"
        const val TOKEN_ENDPOINT = "https://oauth2.googleapis.com/token"
        const val REDIRECT_URI = "com.example.android_p2p_project:/oauth2redirect"
        const val CLIENT_ID = "YOUR_CLIENT_ID"
        const val SCOPE = "openid profile"
        const val DISPLAY_NAME_PREF_KEY = "display_name"
    }

    fun performAuthRequest() {
        val serviceConfiguration = AuthorizationServiceConfiguration(
            Uri.parse(AUTH_ENDPOINT),
            Uri.parse(TOKEN_ENDPOINT)
        )

        val authRequest = AuthorizationRequest.Builder(
            serviceConfiguration,
            CLIENT_ID,
            ResponseTypeValues.CODE,
            Uri.parse(REDIRECT_URI)
        )
            .setScope(SCOPE)
            .build()

        val customTabsIntent = CustomTabsIntent.Builder().build()

        val authIntent = authService.getAuthorizationRequestIntent(
            authRequest,
            customTabsIntent,
            BrowserAllowList(VersionRange.atLeast("1.0")), // Allow all browsers that support Custom Tabs
            BrowserBlacklist() // No specific blacklisted browsers
        )

        context.startActivity(authIntent)
    }

    fun handleAuthorizationResponse(intent: Intent, callback: (String?, String?) -> Unit) {
        val response = AuthorizationResponse.fromIntent(intent)
        val ex = AuthorizationException.fromIntent(intent)

        if (response != null) {
            val tokenRequest = response.createTokenExchangeRequest()
            authService.performTokenRequest(tokenRequest) { tokenResponse, ex ->
                if (tokenResponse != null) {
                    // Successfully exchanged code for tokens
                    val accessToken = tokenResponse.accessToken
                    // You might also get idToken, refreshToken, etc.
                    // For simplicity, we'll just return the access token for now
                    callback(accessToken, null)
                } else {
                    // Token exchange failed
                    callback(null, ex?.message)
                }
            }
        } else {
            // Authorization failed
            callback(null, ex?.message)
        }
    }

    fun dispose() {
        authService.dispose()
        executor.shutdown()
    }
}


