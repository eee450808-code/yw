package com.example.android_p2p_project

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.Window
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner

class CreateSessionDialog(context: Context, private val onCreateSession: (String, String) -> Unit) : Dialog(context) {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.dialog_create_session)

        val spinnerSessionType: Spinner = findViewById(R.id.spinnerSessionType)
        val etUserName: EditText = findViewById(R.id.etUserName)
        val btnCreate: Button = findViewById(R.id.btnCreate)
        val btnCancel: Button = findViewById(R.id.btnCancel)

        ArrayAdapter.createFromResource(
            context,
            R.array.session_types,
            android.R.layout.simple_spinner_item
        ).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinnerSessionType.adapter = adapter
        }

        btnCreate.setOnClickListener {
            val sessionType = spinnerSessionType.selectedItem.toString()
            val userName = etUserName.text.toString().trim()
            if (userName.isNotEmpty()) {
                onCreateSession(sessionType, userName)
                dismiss()
            } else {
                etUserName.error = "User name cannot be empty"
            }
        }

        btnCancel.setOnClickListener {
            dismiss()
        }
    }
}


