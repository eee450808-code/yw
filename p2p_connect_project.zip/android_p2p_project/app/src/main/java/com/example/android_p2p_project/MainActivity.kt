package com.example.android_p2p_project

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    
    companion object {
        private const val PERMISSION_REQUEST_CODE = 1001
        private const val SCREEN_CAPTURE_REQUEST_CODE = 1002
        private const val AUTH_REQUEST_CODE = 1003 // New request code for authentication
        
        private val REQUIRED_PERMISSIONS = arrayOf(
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.INTERNET,
            Manifest.permission.ACCESS_NETWORK_STATE,
            Manifest.permission.MODIFY_AUDIO_SETTINGS
        )
    }
    
    private lateinit var webRTCManager: WebRTCManager
    private lateinit var signalingClient: SignalingClient
    private lateinit var authManager: AuthManager // New AuthManager instance
    private var mediaProjectionManager: MediaProjectionManager? = null
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        initializeComponents()
        setupClickListeners()
        checkPermissions()

        // Handle deep links when the app is launched
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        // Handle deep links when the app is already running
        intent?.let { handleIntent(it) }
    }

    private fun handleIntent(intent: Intent) {
        val appLinkAction = intent.action
        val appLinkData: Uri? = intent.data

        if (Intent.ACTION_VIEW == appLinkAction && appLinkData != null) {
            val sessionId = extractSessionIdFromLink(appLinkData.toString())
            if (sessionId != null) {
                // For simplicity, we'll just show a toast. In a real app, you'd navigate to the session.
                Toast.makeText(this, "Deep Link Session ID: $sessionId", Toast.LENGTH_LONG).show()
                // You might want to automatically join the session here
                // joinSession(sessionId, UserPreferences.getUserName(this) ?: "Guest")
            } else {
                Toast.makeText(this, "Invalid deep link", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    private fun initializeComponents() {
        mediaProjectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        
        // Initialize WebRTC Manager
        webRTCManager = WebRTCManager(this)
        
        // Initialize Signaling Client
        signalingClient = SignalingClient(this, webRTCManager)

        // Initialize Auth Manager
        authManager = AuthManager(this)
        
        // Set callbacks
        webRTCManager.setSignalingClient(signalingClient)
    }
    
    private fun setupClickListeners() {
        btnCreateSession.setOnClickListener {
            if (hasAllPermissions()) {
                showCreateSessionDialog()
            } else {
                requestPermissions()
            }
        }
        
        btnJoinByLink.setOnClickListener {
            if (hasAllPermissions()) {
                showJoinByLinkDialog()
            } else {
                requestPermissions()
            }
        }
        
        btnJoinByCode.setOnClickListener {
            if (hasAllPermissions()) {
                showJoinByCodeDialog()
            } else {
                requestPermissions()
            }
        }
        
        btnStartScreenShare.setOnClickListener {
            startScreenCapture()
        }
        
        btnStopScreenShare.setOnClickListener {
            webRTCManager.stopScreenShare()
            updateScreenShareButtons(false)
        }
        
        btnMuteAudio.setOnClickListener {
            val isMuted = webRTCManager.toggleAudioMute()
            btnMuteAudio.text = if (isMuted) "Unmute Audio" else "Mute Audio"
        }

        // New login button click listener
        btnLoginWithGoogle.setOnClickListener {
            authManager.performAuthRequest()
        }
    }
    
    private fun checkPermissions() {
        if (!hasAllPermissions()) {
            requestPermissions()
        }
    }
    
    private fun hasAllPermissions(): Boolean {
        return REQUIRED_PERMISSIONS.all { permission ->
            ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
        }
    }
    
    private fun requestPermissions() {
        ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, PERMISSION_REQUEST_CODE)
    }
    
    private fun startScreenCapture() {
        mediaProjectionManager?.let { manager ->
            val captureIntent = manager.createScreenCaptureIntent()
            startActivityForResult(captureIntent, SCREEN_CAPTURE_REQUEST_CODE)
        }
    }
    
    private fun showCreateSessionDialog() {
        val dialog = CreateSessionDialog(this) { sessionType, userName ->
            createSession(sessionType, userName)
        }
        dialog.show()
    }
    
    private fun showJoinByLinkDialog() {
        val dialog = JoinByLinkDialog(this) { sessionLink, userName ->
            joinSessionByLink(sessionLink, userName)
        }
        dialog.show()
    }
    
    private fun showJoinByCodeDialog() {
        val dialog = JoinByCodeDialog(this) { sessionCode, userName ->
            joinSessionByCode(sessionCode, userName)
        }
        dialog.show()
    }
    
    private fun createSession(sessionType: String, userName: String) {
        val deviceId = DeviceUtils.getDeviceId(this)
        val userId = UserPreferences.getUserId(this) ?: DeviceUtils.generateUserId()
        
        UserPreferences.saveUserName(this, userName)
        UserPreferences.saveUserId(this, userId)
        
        signalingClient.createSession(sessionType, userId, userName, deviceId) { success, response ->
            runOnUiThread {
                if (success && response != null) {
                    showSessionCreatedDialog(response)
                } else {
                    Toast.makeText(this, "Failed to create session", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    
    private fun joinSessionByLink(sessionLink: String, userName: String) {
        val sessionId = extractSessionIdFromLink(sessionLink)
        if (sessionId != null) {
            joinSession(sessionId, userName)
        } else {
            Toast.makeText(this, "Invalid session link", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun joinSessionByCode(sessionCode: String, userName: String) {
        val deviceId = DeviceUtils.getDeviceId(this)
        val userId = UserPreferences.getUserId(this) ?: DeviceUtils.generateUserId()
        
        UserPreferences.saveUserName(this, userName)
        UserPreferences.saveUserId(this, userId)
        
        signalingClient.joinSessionByCode(sessionCode, userId, userName, deviceId) { success, response ->
            runOnUiThread {
                if (success && response != null) {
                    startSessionActivity(response.sessionId, response.sessionType, response.userRole)
                } else {
                    Toast.makeText(this, "Failed to join session", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    
    private fun joinSession(sessionId: String, userName: String) {
        val deviceId = DeviceUtils.getDeviceId(this)
        val userId = UserPreferences.getUserId(this) ?: DeviceUtils.generateUserId()
        
        UserPreferences.saveUserName(this, userName)
        UserPreferences.saveUserId(this, userId)
        
        signalingClient.joinSession(sessionId, userId, userName, deviceId) { success, response ->
            runOnUiThread {
                if (success && response != null) {
                    startSessionActivity(sessionId, response.sessionType, response.userRole)
                } else {
                    Toast.makeText(this, "Failed to join session", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    
    private fun extractSessionIdFromLink(link: String): String? {
        // Extract session ID from https://p2p.app/s/{sessionId} or p2p://join?sid={sessionId}
        val httpsRegex = Regex("https://p2p\\.app/s/([a-fA-F0-9-]+)")
        val protocolRegex = Regex("p2p://join\\?sid=([a-fA-F0-9-]+)")

        val httpsMatch = httpsRegex.find(link)
        if (httpsMatch != null) {
            return httpsMatch.groupValues[1]
        }

        val protocolMatch = protocolRegex.find(link)
        if (protocolMatch != null) {
            return protocolMatch.groupValues[1]
        }
        return null
    }
    
    private fun showSessionCreatedDialog(response: CreateSessionResponse) {
        val dialog = SessionCreatedDialog(this, response) { sessionId, sessionType ->
            // When session is started from the dialog, we assume the creator is an admin
            startSessionActivity(sessionId, sessionType, UserRole.ADMIN.name)
        }
        dialog.show()
    }
    
    private fun startSessionActivity(sessionId: String, sessionType: String, userRole: String) {
        val intent = Intent(this, SessionActivity::class.java).apply {
            putExtra("SESSION_ID", sessionId)
            putExtra("SESSION_TYPE", sessionType)
            putExtra("USER_ROLE", userRole)
        }
        startActivity(intent)
    }
    
    private fun updateScreenShareButtons(isSharing: Boolean) {
        btnStartScreenShare.isEnabled = !isSharing
        btnStopScreenShare.isEnabled = isSharing
    }
    
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        
        when (requestCode) {
            SCREEN_CAPTURE_REQUEST_CODE -> {
                if (resultCode == RESULT_OK && data != null) {
                    webRTCManager.startScreenShare(resultCode, data)
                    updateScreenShareButtons(true)
                } else {
                    Toast.makeText(this, "Screen capture permission denied", Toast.LENGTH_SHORT).show()
                }
            }
            AUTH_REQUEST_CODE -> {
                if (data != null) {
                    authManager.handleAuthorizationResponse(data) { accessToken, error ->
                        if (accessToken != null) {
                            Toast.makeText(this, "Authentication successful!", Toast.LENGTH_SHORT).show()
                            // TODO: Use the access token for further API calls or save it
                        } else {
                            Toast.makeText(this, "Authentication failed: ${error}", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }
        }
    }
    
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        
        when (requestCode) {
            PERMISSION_REQUEST_CODE -> {
                if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                    Toast.makeText(this, "All permissions granted", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Some permissions were denied", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    
    override fun onDestroy() {
        super.onDestroy()
        webRTCManager.cleanup()
        signalingClient.disconnect()
        authManager.dispose()
    }
}


