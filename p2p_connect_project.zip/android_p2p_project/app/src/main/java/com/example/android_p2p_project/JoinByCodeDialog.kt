package com.example.android_p2p_project

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.Window
import android.widget.Button
import android.widget.EditText

class JoinByCodeDialog(context: Context, private val onJoinSession: (String, String) -> Unit) : Dialog(context) {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.dialog_join_by_code)

        val etSessionCode: EditText = findViewById(R.id.etSessionCode)
        val etUserName: EditText = findViewById(R.id.etUserName)
        val btnJoin: Button = findViewById(R.id.btnJoin)
        val btnCancel: Button = findViewById(R.id.btnCancel)

        btnJoin.setOnClickListener {
            val sessionCode = etSessionCode.text.toString().trim()
            val userName = etUserName.text.toString().trim()
            if (sessionCode.isNotEmpty() && userName.isNotEmpty()) {
                onJoinSession(sessionCode, userName)
                dismiss()
            } else {
                if (sessionCode.isEmpty()) etSessionCode.error = "Session code cannot be empty"
                if (userName.isEmpty()) etUserName.error = "User name cannot be empty"
            }
        }

        btnCancel.setOnClickListener {
            dismiss()
        }
    }
}


