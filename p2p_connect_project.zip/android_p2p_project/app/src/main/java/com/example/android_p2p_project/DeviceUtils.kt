package com.example.android_p2p_project

import android.content.Context
import android.provider.Settings
import java.util.*

object DeviceUtils {
    
    fun getDeviceId(context: Context): String {
        return Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
    }
    
    fun generateUserId(): String {
        return UUID.randomUUID().toString()
    }
    
    fun getDeviceModel(): String {
        return "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}"
    }
    
    fun getAndroidVersion(): String {
        return android.os.Build.VERSION.RELEASE
    }
}

