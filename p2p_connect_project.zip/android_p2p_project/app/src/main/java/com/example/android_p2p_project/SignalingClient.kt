package com.example.android_p2p_project

import android.content.Context
import android.util.Log
import io.socket.client.IO
import io.socket.client.Socket
import org.json.JSONObject
import org.webrtc.IceCandidate
import org.webrtc.SessionDescription
import java.net.URISyntaxException

class SignalingClient(
    private val context: Context,
    private val webRTCManager: WebRTCManager
) {
    
    companion object {
        private const val TAG = "SignalingClient"
        private const val SERVER_URL = "http://10.0.2.2:3000" // For Android emulator
        // Use actual server IP for real devices: "http://YOUR_SERVER_IP:3000"
    }
    
    private var socket: Socket? = null
    private var currentSessionId: String? = null
    private var currentDeviceId: String? = null
    private var currentSessionType: SessionType? = null
    private var currentUserRole: UserRole? = null
    
    init {
        initializeSocket()
    }
    
    private fun initializeSocket() {
        try {
            socket = IO.socket(SERVER_URL)
            setupSocketListeners()
        } catch (e: URISyntaxException) {
            Log.e(TAG, "Failed to initialize socket", e)
        }
    }
    
    private fun setupSocketListeners() {
        socket?.apply {
            on(Socket.EVENT_CONNECT) {
                Log.d(TAG, "Connected to signaling server")
            }
            
            on(Socket.EVENT_DISCONNECT) {
                Log.d(TAG, "Disconnected from signaling server")
            }
            
            on(Socket.EVENT_CONNECT_ERROR) { args ->
                Log.e(TAG, "Connection error: ${args[0]}")
            }
            
            on("joined-session") { args ->
                handleJoinedSession(args[0] as JSONObject)
            }
            
            on("user-joined") { args ->
                handleUserJoined(args[0] as JSONObject)
            }
            
            on("user-left") { args ->
                handleUserLeft(args[0] as JSONObject)
            }
            
            on("offer") { args ->
                handleOffer(args[0] as JSONObject)
            }
            
            on("answer") { args ->
                handleAnswer(args[0] as JSONObject)
            }
            
            on("ice-candidate") { args ->
                handleIceCandidate(args[0] as JSONObject)
            }
            
            on("user-started-screen-share") { args ->
                handleUserStartedScreenShare(args[0] as JSONObject)
            }
            
            on("user-stopped-screen-share") { args ->
                handleUserStoppedScreenShare(args[0] as JSONObject)
            }
            
            on("control-request") { args ->
                handleControlRequest(args[0] as JSONObject)
            }
            
            on("control-response") { args ->
                handleControlResponse(args[0] as JSONObject)
            }
            
            on("session-ended") { args ->
                handleSessionEnded(args[0] as JSONObject)
            }
            
            on("error") { args ->
                Log.e(TAG, "Server error: ${args[0]}")
            }
        }
    }
    
    fun connect() {
        socket?.connect()
    }
    
    fun disconnect() {
        socket?.disconnect()
    }
    
    fun createSession(
        sessionType: String,
        userId: String,
        userName: String,
        deviceId: String,
        callback: (Boolean, CreateSessionResponse?) -> Unit
    ) {
        val url = "$SERVER_URL/api/sessions/create"
        val requestBody = JSONObject().apply {
            put("type", sessionType)
            put("creatorId", userId)
            put("creatorName", userName)
            put("deviceId", deviceId)
        }
        
        NetworkUtils.postRequest(url, requestBody) { success, response ->
            if (success && response != null) {
                try {
                    val sessionResponse = CreateSessionResponse(
                        sessionId = response.getString("sessionId"),
                        sessionCode = response.getString("sessionCode"),
                        sessionLink = response.getString("sessionLink"),
                        type = response.getString("type")
                    )
                    callback(true, sessionResponse)
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to parse create session response", e)
                    callback(false, null)
                }
            } else {
                callback(false, null)
            }
        }
    }
    
    fun joinSession(
        sessionId: String,
        userId: String,
        userName: String,
        deviceId: String,
        callback: (Boolean, JoinSessionResponse?) -> Unit
    ) {
        val url = "$SERVER_URL/api/sessions/join/$sessionId"
        val requestBody = JSONObject().apply {
            put("userId", userId)
            put("userName", userName)
            put("deviceId", deviceId)
        }
        
        NetworkUtils.postRequest(url, requestBody) { success, response ->
            if (success && response != null) {
                try {
                    val joinResponse = JoinSessionResponse(
                        sessionId = response.getString("sessionId"),
                        sessionType = response.getString("sessionType"),
                        userRole = response.getString("userRole")
                    )
                    
                    // Connect to WebSocket and join session room
                    currentSessionId = sessionId
                    currentDeviceId = deviceId
                    currentSessionType = SessionType.valueOf(joinResponse.sessionType)
                    currentUserRole = UserRole.valueOf(joinResponse.userRole)
                    connect()
                    joinSessionRoom(sessionId, deviceId)
                    
                    callback(true, joinResponse)
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to parse join session response", e)
                    callback(false, null)
                }
            } else {
                callback(false, null)
            }
        }
    }
    
    fun joinSessionByCode(
        sessionCode: String,
        userId: String,
        userName: String,
        deviceId: String,
        callback: (Boolean, JoinSessionResponse?) -> Unit
    ) {
        val url = "$SERVER_URL/api/sessions/join-by-code"
        val requestBody = JSONObject().apply {
            put("code", sessionCode)
            put("userId", userId)
            put("userName", userName)
            put("deviceId", deviceId)
        }
        
        NetworkUtils.postRequest(url, requestBody) { success, response ->
            if (success && response != null) {
                try {
                    val joinResponse = JoinSessionResponse(
                        sessionId = response.getString("sessionId"),
                        sessionType = response.getString("sessionType"),
                        userRole = response.getString("userRole")
                    )
                    
                    // Connect to WebSocket and join session room
                    currentSessionId = joinResponse.sessionId
                    currentDeviceId = deviceId
                    currentSessionType = SessionType.valueOf(joinResponse.sessionType)
                    currentUserRole = UserRole.valueOf(joinResponse.userRole)
                    connect()
                    joinSessionRoom(joinResponse.sessionId, deviceId)
                    
                    callback(true, joinResponse)
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to parse join session by code response", e)
                    callback(false, null)
                }
            } else {
                callback(false, null)
            }
        }
    }
    
    private fun joinSessionRoom(sessionId: String, deviceId: String) {
        val data = JSONObject().apply {
            put("sessionId", sessionId)
            put("deviceId", deviceId)
        }
        socket?.emit("join-session", data)
    }
    
    fun sendOffer(offer: SessionDescription, targetDeviceId: String) {
        val data = JSONObject().apply {
            put("offer", JSONObject().apply {
                put("type", offer.type.canonicalForm())
                put("sdp", offer.description)
            })
            put("target", targetDeviceId)
        }
        socket?.emit("offer", data)
    }
    
    fun sendAnswer(answer: SessionDescription, targetDeviceId: String) {
        val data = JSONObject().apply {
            put("answer", JSONObject().apply {
                put("type", answer.type.canonicalForm())
                put("sdp", answer.description)
            })
            put("target", targetDeviceId)
        }
        socket?.emit("answer", data)
    }
    
    fun sendIceCandidate(candidate: IceCandidate, targetDeviceId: String) {
        val data = JSONObject().apply {
            put("candidate", JSONObject().apply {
                put("candidate", candidate.sdp)
                put("sdpMid", candidate.sdpMid)
                put("sdpMLineIndex", candidate.sdpMLineIndex)
            })
            put("target", targetDeviceId)
        }
        socket?.emit("ice-candidate", data)
    }
    
    fun notifyScreenShareStarted() {
        socket?.emit("start-screen-share")
    }
    
    fun notifyScreenShareStopped() {
        socket?.emit("stop-screen-share")
    }
    
    fun requestControl(targetDeviceId: String) {
        val data = JSONObject().apply {
            put("targetDeviceId", targetDeviceId)
        }
        socket?.emit("request-control", data)
    }
    
    fun respondToControlRequest(requesterId: String, granted: Boolean) {
        val data = JSONObject().apply {
            put("requesterId", requesterId)
            put("granted", granted)
        }
        socket?.emit("control-response", data)
    }
    
    private fun handleJoinedSession(data: JSONObject) {
        Log.d(TAG, "Joined session successfully")
        val participants = data.getJSONArray("participants")
        
        // Create peer connections for existing participants based on session type and role
        for (i in 0 until participants.length()) {
            val participant = participants.getJSONObject(i)
            val deviceId = participant.getString("deviceId")
            val participantRole = UserRole.valueOf(participant.getString("userRole"))
            
            if (deviceId != currentDeviceId) {
                currentSessionType?.let { sessionType ->
                    currentUserRole?.let { userRole ->
                        if (SessionPermissions.canViewOtherScreens(sessionType, userRole)) {
                            webRTCManager.createRemotePeerConnection(deviceId)
                        }
                    }
                }
            }
        }
    }
    
    private fun handleUserJoined(data: JSONObject) {
        val userId = data.getString("userId")
        val userName = data.getString("userName")
        val userRole = UserRole.valueOf(data.getString("userRole"))
        val deviceId = data.getString("deviceId")
        
        Log.d(TAG, "User joined: $userName ($userRole)")
        
        // Create peer connection for new user and send offer based on session type and role
        currentSessionType?.let { sessionType ->
            currentUserRole?.let { myRole ->
                if (SessionPermissions.canViewOtherScreens(sessionType, myRole)) {
                    webRTCManager.createRemotePeerConnection(deviceId)
                }
            }
        }
    }
    
    private fun handleUserLeft(data: JSONObject) {
        val userId = data.getString("userId")
        val userName = data.getString("userName")
        val deviceId = data.getString("deviceId")
        
        Log.d(TAG, "User left: $userName")
        
        // Clean up peer connection for the user who left
        webRTCManager.removeRemotePeerConnection(deviceId)
    }
    
    private fun handleOffer(data: JSONObject) {
        val offerData = data.getJSONObject("offer")
        val senderDeviceId = data.getString("sender")
        
        val offer = SessionDescription(
            SessionDescription.Type.OFFER,
            offerData.getString("sdp")
        )
        
        Log.d(TAG, "Received offer from: $senderDeviceId")
        
        // Set remote description and create answer
        webRTCManager.setRemoteDescription(senderDeviceId, offer) {
            webRTCManager.createAnswer(senderDeviceId) { answer ->
                answer?.let {
                    sendAnswer(it, senderDeviceId)
                }
            }
        }
    }
    
    private fun handleAnswer(data: JSONObject) {
        val answerData = data.getJSONObject("answer")
        val senderDeviceId = data.getString("sender")
        
        val answer = SessionDescription(
            SessionDescription.Type.ANSWER,
            answerData.getString("sdp")
        )
        
        Log.d(TAG, "Received answer from: $senderDeviceId")
        
        // Set remote description
        webRTCManager.setRemoteDescription(senderDeviceId, answer) {
            Log.d(TAG, "Remote description set successfully")
        }
    }
    
    private fun handleIceCandidate(data: JSONObject) {
        val candidateData = data.getJSONObject("candidate")
        val senderDeviceId = data.getString("sender")
        
        val candidate = IceCandidate(
            candidateData.getString("sdpMid"),
            candidateData.getInt("sdpMLineIndex"),
            candidateData.getString("candidate")
        )
        
        Log.d(TAG, "Received ICE candidate from: $senderDeviceId")
        
        webRTCManager.addIceCandidate(senderDeviceId, candidate)
    }
    
    private fun handleUserStartedScreenShare(data: JSONObject) {
        val userId = data.getString("userId")
        val userName = data.getString("userName")
        
        Log.d(TAG, "User started screen share: $userName")
        
        // Update UI to show screen share indicator
        // This would be handled by the activity/fragment
    }
    
    private fun handleUserStoppedScreenShare(data: JSONObject) {
        val userId = data.getString("userId")
        val userName = data.getString("userName")
        
        Log.d(TAG, "User stopped screen share: $userName")
        
        // Update UI to hide screen share indicator
        // This would be handled by the activity/fragment
    }
    
    private fun handleControlRequest(data: JSONObject) {
        val requesterId = data.getString("requesterId")
        val requesterName = data.getString("requesterName")
        
        Log.d(TAG, "Control request from: $requesterName")
        
        // Show dialog to user asking for permission
        // This would be handled by the activity/fragment
    }
    
    private fun handleControlResponse(data: JSONObject) {
        val granted = data.getBoolean("granted")
        val targetId = data.getString("targetId")
        
        Log.d(TAG, "Control request response: granted=$granted, target=$targetId")
        
        // Handle control permission response
        // This would be handled by the activity/fragment
    }
    
    private fun handleSessionEnded(data: JSONObject) {
        val reason = data.getString("reason")
        
        Log.d(TAG, "Session ended: $reason")
        
        // Clean up and return to main activity
        // This would be handled by the activity/fragment
    }
}

// Data classes for responses
data class CreateSessionResponse(
    val sessionId: String,
    val sessionCode: String,
    val sessionLink: String,
    val type: String
)

data class JoinSessionResponse(
    val sessionId: String,
    val sessionType: String,
    val userRole: String
)



