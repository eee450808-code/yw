package com.example.android_p2p_project

import android.util.Log
import org.json.JSONObject
import java.io.*
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

object NetworkUtils {
    
    private const val TAG = "NetworkUtils"
    private val executor = Executors.newCachedThreadPool()
    
    fun postRequest(
        url: String,
        requestBody: JSONObject,
        callback: (Boolean, JSONObject?) -> Unit
    ) {
        executor.execute {
            try {
                val connection = URL(url).openConnection() as HttpURLConnection
                connection.apply {
                    requestMethod = "POST"
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Accept", "application/json")
                    doOutput = true
                    doInput = true
                }
                
                // Write request body
                val outputStream = connection.outputStream
                val writer = BufferedWriter(OutputStreamWriter(outputStream, "UTF-8"))
                writer.write(requestBody.toString())
                writer.flush()
                writer.close()
                outputStream.close()
                
                // Read response
                val responseCode = connection.responseCode
                val inputStream = if (responseCode == HttpURLConnection.HTTP_OK) {
                    connection.inputStream
                } else {
                    connection.errorStream
                }
                
                val reader = BufferedReader(InputStreamReader(inputStream))
                val response = StringBuilder()
                var line: String?
                
                while (reader.readLine().also { line = it } != null) {
                    response.append(line)
                }
                
                reader.close()
                inputStream.close()
                connection.disconnect()
                
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    val jsonResponse = JSONObject(response.toString())
                    callback(true, jsonResponse)
                } else {
                    Log.e(TAG, "HTTP Error: $responseCode, Response: $response")
                    callback(false, null)
                }
                
            } catch (e: Exception) {
                Log.e(TAG, "Network request failed", e)
                callback(false, null)
            }
        }
    }
    
    fun getRequest(
        url: String,
        callback: (Boolean, JSONObject?) -> Unit
    ) {
        executor.execute {
            try {
                val connection = URL(url).openConnection() as HttpURLConnection
                connection.apply {
                    requestMethod = "GET"
                    setRequestProperty("Accept", "application/json")
                    doInput = true
                }
                
                val responseCode = connection.responseCode
                val inputStream = if (responseCode == HttpURLConnection.HTTP_OK) {
                    connection.inputStream
                } else {
                    connection.errorStream
                }
                
                val reader = BufferedReader(InputStreamReader(inputStream))
                val response = StringBuilder()
                var line: String?
                
                while (reader.readLine().also { line = it } != null) {
                    response.append(line)
                }
                
                reader.close()
                inputStream.close()
                connection.disconnect()
                
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    val jsonResponse = JSONObject(response.toString())
                    callback(true, jsonResponse)
                } else {
                    Log.e(TAG, "HTTP Error: $responseCode, Response: $response")
                    callback(false, null)
                }
                
            } catch (e: Exception) {
                Log.e(TAG, "Network request failed", e)
                callback(false, null)
            }
        }
    }
}

