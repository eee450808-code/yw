package com.example.android_p2p_project

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_session.*

class SessionActivity : AppCompatActivity() {

    private lateinit var sessionId: String
    private lateinit var sessionType: SessionType
    private lateinit var userRole: UserRole

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_session)

        sessionId = intent.getStringExtra("SESSION_ID") ?: ""
        sessionType = SessionType.valueOf(intent.getStringExtra("SESSION_TYPE") ?: SessionType.DESK.name)
        userRole = UserRole.valueOf(intent.getStringExtra("USER_ROLE") ?: UserRole.MEMBER.name)

        tvSessionInfo.text = "Session ID: $sessionId\nType: ${sessionType.name}\nRole: ${userRole.name}"

        applyPermissions()
    }

    private fun applyPermissions() {
        // Example: Control screen sharing button visibility based on permissions
        btnSessionStartScreenShare.isEnabled = SessionPermissions.canShareScreen(sessionType, userRole)
        btnSessionStopScreenShare.isEnabled = SessionPermissions.canShareScreen(sessionType, userRole)

        // Example: Control remote control request button visibility
        btnRequestControl.isEnabled = SessionPermissions.canRequestControl(sessionType, userRole)

        // You would also control other UI elements and WebRTC functionalities here
        // based on the SessionPermissions object.

        Toast.makeText(this, "Permissions applied for ${sessionType.name} as ${userRole.name}", Toast.LENGTH_LONG).show()
    }
}


