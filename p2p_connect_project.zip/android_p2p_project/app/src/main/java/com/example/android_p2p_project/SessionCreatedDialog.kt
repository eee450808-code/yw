package com.example.android_p2p_project

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.Window
import android.widget.Button
import android.widget.TextView

class SessionCreatedDialog(context: Context, private val sessionResponse: CreateSessionResponse, private val onStartSession: (String, String) -> Unit) : Dialog(context) {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.dialog_session_created)

        val tvSessionId: TextView = findViewById(R.id.tvSessionId)
        val tvSessionCode: TextView = findViewById(R.id.tvSessionCode)
        val tvSessionLink: TextView = findViewById(R.id.tvSessionLink)
        val tvSessionType: TextView = findViewById(R.id.tvSessionType)
        val btnStartSession: Button = findViewById(R.id.btnStartSession)
        val btnCopyLink: Button = findViewById(R.id.btnCopyLink)

        tvSessionId.text = "Session ID: ${sessionResponse.sessionId}"
        tvSessionCode.text = "Session Code: ${sessionResponse.sessionCode}"
        tvSessionLink.text = "Session Link: ${sessionResponse.sessionLink}"
        tvSessionType.text = "Session Type: ${sessionResponse.type}"

        btnStartSession.setOnClickListener {
            onStartSession(sessionResponse.sessionId, sessionResponse.type)
            dismiss()
        }

        btnCopyLink.setOnClickListener {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            val clip = android.content.ClipData.newPlainText("Session Link", sessionResponse.sessionLink)
            clipboard.setPrimaryClip(clip)
            // Optionally, show a toast message
        }
    }
}


