package com.example.android_p2p_project

import android.content.Context
import android.content.SharedPreferences

object UserPreferences {
    
    private const val PREFS_NAME = "P2PUserPrefs"
    private const val KEY_USER_ID = "user_id"
    private const val KEY_USER_NAME = "user_name"
    private const val KEY_DISPLAY_NAME = "display_name"
    private const val KEY_GOOGLE_EMAIL = "google_email"
    
    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }
    
    fun saveUserId(context: Context, userId: String) {
        getPrefs(context).edit().putString(KEY_USER_ID, userId).apply()
    }
    
    fun getUserId(context: Context): String? {
        return getPrefs(context).getString(KEY_USER_ID, null)
    }
    
    fun saveUserName(context: Context, userName: String) {
        getPrefs(context).edit().putString(KEY_USER_NAME, userName).apply()
    }
    
    fun getUserName(context: Context): String? {
        return getPrefs(context).getString(KEY_USER_NAME, null)
    }
    
    fun saveDisplayName(context: Context, displayName: String) {
        getPrefs(context).edit().putString(KEY_DISPLAY_NAME, displayName).apply()
    }
    
    fun getDisplayName(context: Context): String? {
        return getPrefs(context).getString(KEY_DISPLAY_NAME, null)
    }
    
    fun saveGoogleEmail(context: Context, email: String) {
        getPrefs(context).edit().putString(KEY_GOOGLE_EMAIL, email).apply()
    }
    
    fun getGoogleEmail(context: Context): String? {
        return getPrefs(context).getString(KEY_GOOGLE_EMAIL, null)
    }
    
    fun clearUserData(context: Context) {
        getPrefs(context).edit().clear().apply()
    }
}

