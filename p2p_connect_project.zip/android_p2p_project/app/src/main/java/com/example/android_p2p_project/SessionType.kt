package com.example.android_p2p_project

enum class SessionType {
    DESK,
    TEAM,
    CLASS
}

enum class UserRole {
    ADMIN,
    MEMBER,
    STUDENT,
    TEACHER
}

// Define permissions for each session type and role
object SessionPermissions {
    fun canShareScreen(sessionType: SessionType, role: UserRole): Boolean {
        return when (sessionType) {
            SessionType.DESK -> role == UserRole.ADMIN || role == UserRole.MEMBER // Assuming Desk is 1:1 or simple sharing
            SessionType.TEAM -> role == UserRole.ADMIN || role == UserRole.MEMBER
            SessionType.CLASS -> role == UserRole.TEACHER // Only teacher can share screen initially
        }
    }

    fun canControlRemote(sessionType: SessionType, role: UserRole): Boolean {
        return when (sessionType) {
            SessionType.DESK -> role == UserRole.ADMIN || role == UserRole.MEMBER
            SessionType.TEAM -> role == UserRole.ADMIN
            SessionType.CLASS -> role == UserRole.TEACHER
        }
    }

    fun canRequestControl(sessionType: SessionType, role: UserRole): Boolean {
        return when (sessionType) {
            SessionType.DESK -> role == UserRole.MEMBER
            SessionType.TEAM -> role == UserRole.MEMBER
            SessionType.CLASS -> role == UserRole.STUDENT
        }
    }

    fun canViewOtherScreens(sessionType: SessionType, role: UserRole): Boolean {
        return when (sessionType) {
            SessionType.DESK -> true // Both can view each other
            SessionType.TEAM -> role == UserRole.ADMIN || role == UserRole.MEMBER
            SessionType.CLASS -> role == UserRole.TEACHER // Teacher sees all student screens
        }
    }

    // Add more permission checks as needed
}


