/**
 * Security Testing Script for P2P Signaling Server
 * 
 * This script tests various security aspects:
 * - Input validation and sanitization
 * - SQL injection attempts
 * - XSS prevention
 * - CSRF protection
 * - Rate limiting
 * - Authentication bypass attempts
 * - Data leakage prevention
 */

const axios = require('axios');
const WebSocket = require('ws');

class SecurityTester {
    constructor(serverUrl = 'http://localhost:3000', wsUrl = 'ws://localhost:3000') {
        this.serverUrl = serverUrl;
        this.wsUrl = wsUrl;
        this.vulnerabilities = [];
        this.testResults = {
            passed: 0,
            failed: 0,
            warnings: 0
        };
    }

    async runSecurityTests() {
        console.log('🔒 Starting Security Tests for P2P Signaling Server');
        console.log(`Server URL: ${this.serverUrl}`);
        console.log('='.repeat(60));

        try {
            await this.testInputValidation();
            await this.testSQLInjection();
            await this.testXSSPrevention();
            await this.testRateLimiting();
            await this.testAuthenticationBypass();
            await this.testDataLeakage();
            await this.testWebSocketSecurity();
            await this.testHTTPHeaders();
            await this.testFileUploadSecurity();
            await this.testSessionSecurity();
            
        } catch (error) {
            console.error('❌ Security test suite failed:', error);
        } finally {
            this.generateSecurityReport();
        }
    }

    async testInputValidation() {
        console.log('\n🛡️  Testing Input Validation...');
        
        const maliciousInputs = [
            // Oversized inputs
            { field: 'userName', value: 'A'.repeat(10000), description: 'Oversized username' },
            { field: 'userId', value: 'B'.repeat(5000), description: 'Oversized user ID' },
            
            // Special characters
            { field: 'userName', value: '../../etc/passwd', description: 'Path traversal attempt' },
            { field: 'sessionType', value: '../admin', description: 'Path traversal in session type' },
            
            // Null bytes
            { field: 'userName', value: 'user\x00admin', description: 'Null byte injection' },
            
            // Unicode attacks
            { field: 'userName', value: 'user\u202e\u0041dmin', description: 'Unicode right-to-left override' },
            
            // Control characters
            { field: 'userName', value: 'user\r\nSet-Cookie: admin=true', description: 'HTTP header injection' },
        ];

        for (const input of maliciousInputs) {
            try {
                const sessionData = {
                    sessionType: 'desk',
                    userId: 'test-user',
                    userName: 'Test User',
                    deviceId: 'test-device'
                };
                
                sessionData[input.field] = input.value;
                
                const response = await axios.post(`${this.serverUrl}/api/sessions`, sessionData);
                
                // Check if malicious input was properly sanitized
                const responseStr = JSON.stringify(response.data);
                if (responseStr.includes(input.value)) {
                    this.addVulnerability('HIGH', `Input validation bypass: ${input.description}`, {
                        field: input.field,
                        input: input.value.substring(0, 100) + '...'
                    });
                } else {
                    this.testResults.passed++;
                    console.log(`✅ ${input.description} - Properly handled`);
                }
                
            } catch (error) {
                if (error.response && error.response.status === 400) {
                    this.testResults.passed++;
                    console.log(`✅ ${input.description} - Rejected as expected`);
                } else {
                    this.testResults.failed++;
                    console.log(`❌ ${input.description} - Unexpected error: ${error.message}`);
                }
            }
        }
    }

    async testSQLInjection() {
        console.log('\n💉 Testing SQL Injection Prevention...');
        
        const sqlPayloads = [
            "'; DROP TABLE sessions; --",
            "' OR '1'='1",
            "' UNION SELECT * FROM users --",
            "'; INSERT INTO sessions VALUES ('hacked'); --",
            "' OR 1=1 --",
            "admin'--",
            "' OR 'x'='x",
            "'; EXEC xp_cmdshell('dir'); --"
        ];

        for (const payload of sqlPayloads) {
            try {
                const sessionData = {
                    sessionType: 'desk',
                    userId: payload,
                    userName: payload,
                    deviceId: 'test-device'
                };
                
                const response = await axios.post(`${this.serverUrl}/api/sessions`, sessionData);
                
                // Check if SQL injection was successful (shouldn't be)
                if (response.status === 201) {
                    this.addVulnerability('CRITICAL', 'Possible SQL injection vulnerability', {
                        payload: payload,
                        response: response.data
                    });
                }
                
            } catch (error) {
                if (error.response && (error.response.status === 400 || error.response.status === 422)) {
                    this.testResults.passed++;
                    console.log(`✅ SQL injection payload rejected: ${payload.substring(0, 30)}...`);
                } else {
                    this.testResults.warnings++;
                    console.log(`⚠️  Unexpected response to SQL payload: ${error.message}`);
                }
            }
        }
    }

    async testXSSPrevention() {
        console.log('\n🕷️  Testing XSS Prevention...');
        
        const xssPayloads = [
            '<script>alert("XSS")</script>',
            '<img src=x onerror=alert("XSS")>',
            'javascript:alert("XSS")',
            '<svg onload=alert("XSS")>',
            '<iframe src="javascript:alert(\'XSS\')"></iframe>',
            '"><script>alert("XSS")</script>',
            '\';alert("XSS");//',
            '<body onload=alert("XSS")>'
        ];

        for (const payload of xssPayloads) {
            try {
                const sessionData = {
                    sessionType: 'desk',
                    userId: 'test-user',
                    userName: payload,
                    deviceId: 'test-device'
                };
                
                const response = await axios.post(`${this.serverUrl}/api/sessions`, sessionData);
                
                // Check if XSS payload appears unescaped in response
                const responseStr = JSON.stringify(response.data);
                if (responseStr.includes('<script>') || responseStr.includes('javascript:') || 
                    responseStr.includes('onerror=') || responseStr.includes('onload=')) {
                    this.addVulnerability('HIGH', 'XSS vulnerability detected', {
                        payload: payload,
                        response: responseStr.substring(0, 200)
                    });
                } else {
                    this.testResults.passed++;
                    console.log(`✅ XSS payload properly escaped: ${payload.substring(0, 30)}...`);
                }
                
            } catch (error) {
                if (error.response && error.response.status === 400) {
                    this.testResults.passed++;
                    console.log(`✅ XSS payload rejected: ${payload.substring(0, 30)}...`);
                } else {
                    this.testResults.warnings++;
                    console.log(`⚠️  Unexpected response to XSS payload: ${error.message}`);
                }
            }
        }
    }

    async testRateLimiting() {
        console.log('\n🚦 Testing Rate Limiting...');
        
        const rapidRequests = [];
        const startTime = Date.now();
        
        // Send 50 rapid requests
        for (let i = 0; i < 50; i++) {
            rapidRequests.push(
                axios.post(`${this.serverUrl}/api/sessions`, {
                    sessionType: 'desk',
                    userId: `rate-test-${i}`,
                    userName: 'Rate Test User',
                    deviceId: `rate-device-${i}`
                }).catch(error => error.response)
            );
        }
        
        try {
            const responses = await Promise.all(rapidRequests);
            const rateLimitedCount = responses.filter(r => r && r.status === 429).length;
            const successCount = responses.filter(r => r && r.status === 201).length;
            
            if (rateLimitedCount > 0) {
                this.testResults.passed++;
                console.log(`✅ Rate limiting working: ${rateLimitedCount} requests blocked, ${successCount} allowed`);
            } else {
                this.addVulnerability('MEDIUM', 'Rate limiting not implemented or too permissive', {
                    totalRequests: 50,
                    successfulRequests: successCount,
                    blockedRequests: rateLimitedCount
                });
            }
            
        } catch (error) {
            this.testResults.failed++;
            console.log(`❌ Rate limiting test failed: ${error.message}`);
        }
    }

    async testAuthenticationBypass() {
        console.log('\n🔐 Testing Authentication Bypass...');
        
        // Test accessing protected endpoints without proper authentication
        const protectedEndpoints = [
            '/api/admin/versions',
            '/api/admin/config',
            '/api/admin/stats'
        ];
        
        for (const endpoint of protectedEndpoints) {
            try {
                const response = await axios.get(`${this.serverUrl}${endpoint}`);
                
                if (response.status === 200) {
                    this.addVulnerability('HIGH', `Authentication bypass on protected endpoint: ${endpoint}`, {
                        endpoint: endpoint,
                        status: response.status
                    });
                }
                
            } catch (error) {
                if (error.response && (error.response.status === 401 || error.response.status === 403)) {
                    this.testResults.passed++;
                    console.log(`✅ Protected endpoint properly secured: ${endpoint}`);
                } else if (error.response && error.response.status === 404) {
                    this.testResults.warnings++;
                    console.log(`⚠️  Endpoint not found (may not be implemented): ${endpoint}`);
                } else {
                    this.testResults.warnings++;
                    console.log(`⚠️  Unexpected response for ${endpoint}: ${error.message}`);
                }
            }
        }
    }

    async testDataLeakage() {
        console.log('\n📊 Testing Data Leakage Prevention...');
        
        try {
            // Create a session
            const sessionData = {
                sessionType: 'desk',
                userId: 'leak-test-user',
                userName: 'Leak Test User',
                deviceId: 'leak-test-device'
            };
            
            const createResponse = await axios.post(`${this.serverUrl}/api/sessions`, sessionData);
            const sessionId = createResponse.data.sessionId;
            
            // Try to access session with different user
            const response = await axios.get(`${this.serverUrl}/api/sessions/${sessionId}`);
            
            // Check if sensitive information is exposed
            const sensitiveFields = ['deviceId', 'internalId', 'password', 'token', 'secret'];
            const responseStr = JSON.stringify(response.data).toLowerCase();
            
            let leakageDetected = false;
            for (const field of sensitiveFields) {
                if (responseStr.includes(field)) {
                    this.addVulnerability('MEDIUM', `Potential data leakage: ${field} exposed in API response`, {
                        endpoint: `/api/sessions/${sessionId}`,
                        exposedField: field
                    });
                    leakageDetected = true;
                }
            }
            
            if (!leakageDetected) {
                this.testResults.passed++;
                console.log('✅ No obvious data leakage detected in API responses');
            }
            
        } catch (error) {
            this.testResults.warnings++;
            console.log(`⚠️  Data leakage test inconclusive: ${error.message}`);
        }
    }

    async testWebSocketSecurity() {
        console.log('\n🔌 Testing WebSocket Security...');
        
        try {
            const ws = new WebSocket(this.wsUrl);
            
            await new Promise((resolve, reject) => {
                const timeout = setTimeout(() => {
                    reject(new Error('WebSocket connection timeout'));
                }, 5000);
                
                ws.on('open', () => {
                    clearTimeout(timeout);
                    
                    // Test malicious WebSocket messages
                    const maliciousMessages = [
                        { type: 'admin_command', command: 'shutdown_server' },
                        { type: 'sql_injection', query: "'; DROP TABLE sessions; --" },
                        { type: 'buffer_overflow', data: 'A'.repeat(100000) },
                        { type: 'xss', content: '<script>alert("XSS")</script>' }
                    ];
                    
                    maliciousMessages.forEach(msg => {
                        ws.send(JSON.stringify(msg));
                    });
                    
                    setTimeout(() => {
                        ws.close();
                        resolve();
                    }, 2000);
                });
                
                ws.on('error', (error) => {
                    clearTimeout(timeout);
                    reject(error);
                });
                
                ws.on('message', (data) => {
                    const message = data.toString();
                    if (message.includes('<script>') || message.includes('admin_command')) {
                        this.addVulnerability('HIGH', 'WebSocket message validation bypass', {
                            message: message.substring(0, 100)
                        });
                    }
                });
            });
            
            this.testResults.passed++;
            console.log('✅ WebSocket security test completed');
            
        } catch (error) {
            this.testResults.warnings++;
            console.log(`⚠️  WebSocket security test failed: ${error.message}`);
        }
    }

    async testHTTPHeaders() {
        console.log('\n📋 Testing HTTP Security Headers...');
        
        try {
            const response = await axios.get(`${this.serverUrl}/health`);
            const headers = response.headers;
            
            const securityHeaders = {
                'x-content-type-options': 'nosniff',
                'x-frame-options': ['DENY', 'SAMEORIGIN'],
                'x-xss-protection': '1; mode=block',
                'strict-transport-security': 'max-age=',
                'content-security-policy': 'default-src'
            };
            
            for (const [header, expectedValue] of Object.entries(securityHeaders)) {
                const headerValue = headers[header];
                
                if (!headerValue) {
                    this.addVulnerability('LOW', `Missing security header: ${header}`, {
                        header: header,
                        recommendation: `Add ${header} header for better security`
                    });
                } else if (Array.isArray(expectedValue)) {
                    if (!expectedValue.some(val => headerValue.includes(val))) {
                        this.testResults.warnings++;
                        console.log(`⚠️  Security header ${header} may not be properly configured`);
                    } else {
                        this.testResults.passed++;
                        console.log(`✅ Security header ${header} properly configured`);
                    }
                } else if (!headerValue.includes(expectedValue)) {
                    this.testResults.warnings++;
                    console.log(`⚠️  Security header ${header} may not be properly configured`);
                } else {
                    this.testResults.passed++;
                    console.log(`✅ Security header ${header} properly configured`);
                }
            }
            
        } catch (error) {
            this.testResults.warnings++;
            console.log(`⚠️  HTTP headers test failed: ${error.message}`);
        }
    }

    async testFileUploadSecurity() {
        console.log('\n📁 Testing File Upload Security...');
        
        // Test if there are any file upload endpoints that might be vulnerable
        const uploadEndpoints = [
            '/api/upload',
            '/api/admin/upload',
            '/upload',
            '/files/upload'
        ];
        
        for (const endpoint of uploadEndpoints) {
            try {
                const response = await axios.post(`${this.serverUrl}${endpoint}`, {
                    file: 'test content',
                    filename: '../../../etc/passwd'
                });
                
                if (response.status === 200) {
                    this.addVulnerability('HIGH', `Unprotected file upload endpoint: ${endpoint}`, {
                        endpoint: endpoint
                    });
                }
                
            } catch (error) {
                if (error.response && error.response.status === 404) {
                    this.testResults.passed++;
                    console.log(`✅ No file upload endpoint at: ${endpoint}`);
                } else {
                    this.testResults.warnings++;
                    console.log(`⚠️  Unexpected response for ${endpoint}: ${error.message}`);
                }
            }
        }
    }

    async testSessionSecurity() {
        console.log('\n🎫 Testing Session Security...');
        
        try {
            // Create a session
            const sessionData = {
                sessionType: 'desk',
                userId: 'session-test-user',
                userName: 'Session Test User',
                deviceId: 'session-test-device'
            };
            
            const response = await axios.post(`${this.serverUrl}/api/sessions`, sessionData);
            const sessionId = response.data.sessionId;
            
            // Check session ID format and entropy
            if (sessionId.length < 16) {
                this.addVulnerability('MEDIUM', 'Session ID too short, may be predictable', {
                    sessionId: sessionId,
                    length: sessionId.length
                });
            } else {
                this.testResults.passed++;
                console.log('✅ Session ID has adequate length');
            }
            
            // Check if session ID contains only safe characters
            if (!/^[a-zA-Z0-9\-_]+$/.test(sessionId)) {
                this.testResults.warnings++;
                console.log('⚠️  Session ID contains special characters');
            } else {
                this.testResults.passed++;
                console.log('✅ Session ID uses safe character set');
            }
            
        } catch (error) {
            this.testResults.warnings++;
            console.log(`⚠️  Session security test failed: ${error.message}`);
        }
    }

    addVulnerability(severity, description, details = {}) {
        this.vulnerabilities.push({
            severity,
            description,
            details,
            timestamp: new Date().toISOString()
        });
        
        const icon = severity === 'CRITICAL' ? '🚨' : severity === 'HIGH' ? '🔴' : severity === 'MEDIUM' ? '🟡' : '🟠';
        console.log(`${icon} ${severity}: ${description}`);
        
        this.testResults.failed++;
    }

    generateSecurityReport() {
        console.log('\n🔒 SECURITY TEST REPORT');
        console.log('='.repeat(60));
        
        console.log(`✅ Tests Passed: ${this.testResults.passed}`);
        console.log(`❌ Tests Failed: ${this.testResults.failed}`);
        console.log(`⚠️  Warnings: ${this.testResults.warnings}`);
        
        if (this.vulnerabilities.length === 0) {
            console.log('\n🎉 No security vulnerabilities detected!');
            console.log('✅ The application appears to have good security practices.');
        } else {
            console.log(`\n🚨 ${this.vulnerabilities.length} security issues detected:`);
            console.log('-'.repeat(40));
            
            const severityCounts = {
                CRITICAL: 0,
                HIGH: 0,
                MEDIUM: 0,
                LOW: 0
            };
            
            this.vulnerabilities.forEach((vuln, index) => {
                severityCounts[vuln.severity]++;
                console.log(`\n${index + 1}. [${vuln.severity}] ${vuln.description}`);
                if (Object.keys(vuln.details).length > 0) {
                    console.log(`   Details: ${JSON.stringify(vuln.details, null, 2)}`);
                }
            });
            
            console.log('\n📊 Vulnerability Summary:');
            Object.entries(severityCounts).forEach(([severity, count]) => {
                if (count > 0) {
                    const icon = severity === 'CRITICAL' ? '🚨' : severity === 'HIGH' ? '🔴' : severity === 'MEDIUM' ? '🟡' : '🟠';
                    console.log(`   ${icon} ${severity}: ${count}`);
                }
            });
            
            console.log('\n🔧 Recommendations:');
            console.log('1. Fix CRITICAL and HIGH severity issues immediately');
            console.log('2. Implement proper input validation and sanitization');
            console.log('3. Add security headers to all HTTP responses');
            console.log('4. Implement rate limiting on all endpoints');
            console.log('5. Regular security audits and penetration testing');
        }
        
        console.log('\n🏁 Security test completed!');
    }
}

// Run the security tests
async function main() {
    const serverUrl = process.env.SERVER_URL || 'http://localhost:3000';
    const wsUrl = process.env.WS_URL || 'ws://localhost:3000';
    
    const tester = new SecurityTester(serverUrl, wsUrl);
    await tester.runSecurityTests();
}

if (require.main === module) {
    main().catch(error => {
        console.error('❌ Security test failed:', error);
        process.exit(1);
    });
}

module.exports = SecurityTester;

