# دليل النشر والتثبيت - P2P Connect

## 📋 جدول المحتويات

- [نظرة عامة](#نظرة-عامة)
- [متطلبات النشر](#متطلبات-النشر)
- [إعداد البيئة](#إعداد-البيئة)
- [نشر خادم الإشارة](#نشر-خادم-الإشارة)
- [نشر واجهة الإدارة](#نشر-واجهة-الإدارة)
- [نشر صفحة التحميل](#نشر-صفحة-التحميل)
- [إعداد OAuth](#إعداد-oauth)
- [إعداد Firebase](#إعداد-firebase)
- [إعداد Google Apps Script](#إعداد-google-apps-script)
- [بناء تطبيق Android](#بناء-تطبيق-android)
- [المراقبة والصيانة](#المراقبة-والصيانة)
- [استكشاف الأخطاء](#استكشاف-الأخطاء)

## 🌟 نظرة عامة

هذا الدليل يوضح خطوات نشر جميع مكونات نظام P2P Connect في بيئة الإنتاج. النظام يتكون من:

- **تطبيق Android:** التطبيق الرئيسي للمستخدمين
- **خادم الإشارة:** Node.js server للتواصل بين العملاء
- **واجهة الإدارة:** Flask web app لإدارة النظام
- **صفحة التحميل:** React app لتحميل التطبيق
- **خدمات خارجية:** OAuth, Firebase, Google Apps Script

## 🔧 متطلبات النشر

### الخوادم المطلوبة

#### خادم الإنتاج الرئيسي
- **نظام التشغيل:** Ubuntu 20.04 LTS أو أحدث
- **المعالج:** 4 cores كحد أدنى، 8 cores موصى به
- **الذاكرة:** 8 GB RAM كحد أدنى، 16 GB موصى به
- **التخزين:** 100 GB SSD
- **الشبكة:** 1 Gbps bandwidth
- **IP عام:** مطلوب للوصول الخارجي

#### خادم قاعدة البيانات (اختياري)
- **نظام التشغيل:** Ubuntu 20.04 LTS
- **المعالج:** 2 cores كحد أدنى
- **الذاكرة:** 4 GB RAM كحد أدنى
- **التخزين:** 50 GB SSD
- **قاعدة البيانات:** PostgreSQL 13+ أو Redis 6+

### الخدمات الخارجية

- **Google Cloud Console:** لإعداد OAuth
- **Firebase Console:** للإشعارات
- **Google Sheets + Apps Script:** لجمع الإيميلات
- **Domain Name:** نطاق مخصص (اختياري)
- **SSL Certificate:** شهادة SSL (Let's Encrypt مجاني)

## 🚀 إعداد البيئة

### 1. إعداد الخادم الأساسي

```bash
# تحديث النظام
sudo apt update && sudo apt upgrade -y

# تثبيت المتطلبات الأساسية
sudo apt install -y curl wget git nginx certbot python3-certbot-nginx

# تثبيت Node.js 18.x
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# تثبيت Python 3.9+
sudo apt install -y python3 python3-pip python3-venv

# تثبيت PM2 لإدارة العمليات
sudo npm install -g pm2

# إعداد Firewall
sudo ufw allow ssh
sudo ufw allow http
sudo ufw allow https
sudo ufw allow 3000  # Signaling server
sudo ufw allow 5000  # Admin web
sudo ufw --force enable
```

### 2. إنشاء مستخدم التطبيق

```bash
# إنشاء مستخدم مخصص
sudo adduser p2pconnect
sudo usermod -aG sudo p2pconnect

# التبديل للمستخدم الجديد
sudo su - p2pconnect

# إنشاء مجلدات المشروع
mkdir -p ~/apps/p2pconnect
cd ~/apps/p2pconnect
```

### 3. استنساخ المشروع

```bash
# استنساخ المشروع
git clone https://github.com/your-repo/p2p-connect.git .

# إعداد الأذونات
chmod +x scripts/*.sh
```

## 🔄 نشر خادم الإشارة

### 1. إعداد خادم الإشارة

```bash
cd ~/apps/p2pconnect/signaling_server

# تثبيت التبعيات
npm install --production

# إنشاء ملف البيئة
cat > .env << EOF
NODE_ENV=production
PORT=3000
HOST=0.0.0.0
MAX_CONNECTIONS=1000
RATE_LIMIT_WINDOW=900000
RATE_LIMIT_MAX=100
LOG_LEVEL=info
EOF

# اختبار التشغيل
npm start
```

### 2. إعداد PM2

```bash
# إنشاء ملف تكوين PM2
cat > ecosystem.config.js << EOF
module.exports = {
  apps: [{
    name: 'p2p-signaling',
    script: 'server.js',
    cwd: '/home/p2pconnect/apps/p2pconnect/signaling_server',
    instances: 'max',
    exec_mode: 'cluster',
    env: {
      NODE_ENV: 'production',
      PORT: 3000
    },
    error_file: '/var/log/p2pconnect/signaling-error.log',
    out_file: '/var/log/p2pconnect/signaling-out.log',
    log_file: '/var/log/p2pconnect/signaling.log',
    time: true,
    max_memory_restart: '1G',
    restart_delay: 4000
  }]
};
EOF

# إنشاء مجلد اللوجز
sudo mkdir -p /var/log/p2pconnect
sudo chown p2pconnect:p2pconnect /var/log/p2pconnect

# بدء الخدمة
pm2 start ecosystem.config.js
pm2 save
pm2 startup
```

### 3. إعداد Nginx للخادم

```bash
# إنشاء تكوين Nginx
sudo tee /etc/nginx/sites-available/p2p-signaling << EOF
server {
    listen 80;
    server_name signaling.p2pconnect.app;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        proxy_read_timeout 86400;
    }
}
EOF

# تفعيل الموقع
sudo ln -s /etc/nginx/sites-available/p2p-signaling /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx

# إعداد SSL
sudo certbot --nginx -d signaling.p2pconnect.app
```

## 🖥️ نشر واجهة الإدارة

### 1. إعداد واجهة الإدارة

```bash
cd ~/apps/p2pconnect/admin_web

# إنشاء البيئة الافتراضية
python3 -m venv venv
source venv/bin/activate

# تثبيت التبعيات
pip install -r requirements.txt

# إنشاء ملف البيئة
cat > .env << EOF
FLASK_ENV=production
SECRET_KEY=$(python3 -c "import secrets; print(secrets.token_hex(32))")
DATABASE_URL=sqlite:///p2pconnect.db
UPLOAD_FOLDER=/home/p2pconnect/uploads
MAX_CONTENT_LENGTH=104857600
ADMIN_USERNAME=admin
ADMIN_PASSWORD=$(python3 -c "import secrets; print(secrets.token_urlsafe(16))")
EOF

# إنشاء مجلد الرفع
mkdir -p /home/p2pconnect/uploads

# تهيئة قاعدة البيانات
python3 -c "
from src.main import app, db
with app.app_context():
    db.create_all()
    print('Database initialized successfully')
"
```

### 2. إعداد Gunicorn

```bash
# تثبيت Gunicorn
pip install gunicorn

# إنشاء ملف تكوين Gunicorn
cat > gunicorn.conf.py << EOF
bind = "127.0.0.1:5000"
workers = 4
worker_class = "sync"
worker_connections = 1000
timeout = 30
keepalive = 2
max_requests = 1000
max_requests_jitter = 100
preload_app = True
EOF

# إنشاء خدمة systemd
sudo tee /etc/systemd/system/p2p-admin.service << EOF
[Unit]
Description=P2P Connect Admin Web Interface
After=network.target

[Service]
User=p2pconnect
Group=p2pconnect
WorkingDirectory=/home/p2pconnect/apps/p2pconnect/admin_web
Environment=PATH=/home/p2pconnect/apps/p2pconnect/admin_web/venv/bin
ExecStart=/home/p2pconnect/apps/p2pconnect/admin_web/venv/bin/gunicorn -c gunicorn.conf.py src.main:app
Restart=always

[Install]
WantedBy=multi-user.target
EOF

# تفعيل وبدء الخدمة
sudo systemctl daemon-reload
sudo systemctl enable p2p-admin
sudo systemctl start p2p-admin
```

### 3. إعداد Nginx لواجهة الإدارة

```bash
# إنشاء تكوين Nginx
sudo tee /etc/nginx/sites-available/p2p-admin << EOF
server {
    listen 80;
    server_name admin.p2pconnect.app;

    client_max_body_size 100M;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }

    location /uploads/ {
        alias /home/p2pconnect/uploads/;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
EOF

# تفعيل الموقع
sudo ln -s /etc/nginx/sites-available/p2p-admin /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx

# إعداد SSL
sudo certbot --nginx -d admin.p2pconnect.app
```

## 🌐 نشر صفحة التحميل

### 1. بناء صفحة التحميل

```bash
cd ~/apps/p2pconnect/landing_page

# تثبيت التبعيات
npm install

# إنشاء ملف البيئة
cat > .env << EOF
VITE_API_URL=https://admin.p2pconnect.app/api
VITE_SIGNALING_URL=wss://signaling.p2pconnect.app
VITE_GOOGLE_APPS_SCRIPT_URL=https://script.google.com/macros/s/YOUR_SCRIPT_ID/exec
VITE_GOOGLE_APPS_SCRIPT_API_KEY=your-secret-api-key
EOF

# بناء المشروع
npm run build

# نسخ الملفات المبنية
sudo mkdir -p /var/www/p2pconnect
sudo cp -r dist/* /var/www/p2pconnect/
sudo chown -R www-data:www-data /var/www/p2pconnect
```

### 2. إعداد Nginx لصفحة التحميل

```bash
# إنشاء تكوين Nginx
sudo tee /etc/nginx/sites-available/p2p-landing << EOF
server {
    listen 80;
    server_name p2pconnect.app www.p2pconnect.app;
    root /var/www/p2pconnect;
    index index.html;

    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_types text/plain text/css text/xml text/javascript application/javascript application/xml+rss application/json;

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;
    add_header Content-Security-Policy "default-src 'self' http: https: data: blob: 'unsafe-inline'" always;

    # Cache static assets
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    # Handle React Router
    location / {
        try_files \$uri \$uri/ /index.html;
    }

    # API proxy
    location /api/ {
        proxy_pass https://admin.p2pconnect.app/api/;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
}
EOF

# تفعيل الموقع
sudo ln -s /etc/nginx/sites-available/p2p-landing /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx

# إعداد SSL
sudo certbot --nginx -d p2pconnect.app -d www.p2pconnect.app
```

## 🔐 إعداد OAuth

### 1. إعداد Google Cloud Console

1. **إنشاء مشروع جديد:**
   - اذهب إلى [Google Cloud Console](https://console.cloud.google.com)
   - أنشئ مشروع جديد أو اختر مشروع موجود
   - فعّل Google+ API

2. **إنشاء OAuth 2.0 credentials:**
   ```
   APIs & Services > Credentials > Create Credentials > OAuth 2.0 Client ID
   
   Application type: Android
   Package name: com.example.android_p2p_project
   SHA-1 certificate fingerprint: [من Android Studio أو keytool]
   ```

3. **إضافة Redirect URIs:**
   ```
   com.example.android_p2p_project:/oauth2redirect
   https://p2pconnect.app/auth/callback
   ```

### 2. تحديث التطبيق

```kotlin
// في AuthManager.kt
private const val CLIENT_ID = "your-actual-client-id.googleusercontent.com"
private const val REDIRECT_URI = "com.example.android_p2p_project:/oauth2redirect"
```

## 🔔 إعداد Firebase

### 1. إنشاء مشروع Firebase

1. **اذهب إلى [Firebase Console](https://console.firebase.google.com)**
2. **أنشئ مشروع جديد**
3. **أضف تطبيق Android:**
   - Package name: `com.example.android_p2p_project`
   - حمّل `google-services.json`

### 2. إعداد Cloud Messaging

```bash
# في Firebase Console
Project Settings > Cloud Messaging > Server Key

# احفظ Server Key لاستخدامه في خادم الإشارة
```

### 3. تحديث خادم الإشارة

```javascript
// في signaling_server/.env
FIREBASE_SERVER_KEY=your-firebase-server-key
```

## 📊 إعداد Google Apps Script

### 1. إنشاء Google Sheet

1. **أنشئ Google Sheet جديد**
2. **اذهب إلى Extensions > Apps Script**
3. **انسخ محتوى `google_apps_script.js`**

### 2. نشر كـ Web App

```javascript
// في Apps Script Editor
Deploy > New Deployment > Type: Web app

Execute as: Me
Who has access: Anyone

// احفظ Web App URL
```

### 3. تحديث API Key

```javascript
// في google_apps_script.js
const API_KEY = 'your-secure-random-api-key-here';
```

## 📱 بناء تطبيق Android

### 1. إعداد بيئة البناء

```bash
# تثبيت Android SDK (إذا لم يكن مثبتاً)
wget https://dl.google.com/android/repository/commandlinetools-linux-8512546_latest.zip
unzip commandlinetools-linux-8512546_latest.zip
mkdir -p ~/android-sdk/cmdline-tools/latest
mv cmdline-tools/* ~/android-sdk/cmdline-tools/latest/

# إعداد متغيرات البيئة
echo 'export ANDROID_HOME=~/android-sdk' >> ~/.bashrc
echo 'export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools' >> ~/.bashrc
source ~/.bashrc

# تثبيت المتطلبات
sdkmanager "platform-tools" "platforms;android-30" "build-tools;30.0.3"
```

### 2. بناء APK

```bash
cd ~/apps/p2pconnect

# تنظيف المشروع
./gradlew clean

# بناء APK للإنتاج
./gradlew assembleRelease

# توقيع APK (إنشاء keystore أولاً)
keytool -genkey -v -keystore p2pconnect.keystore -alias p2pconnect -keyalg RSA -keysize 2048 -validity 10000

# توقيع APK
jarsigner -verbose -sigalg SHA1withRSA -digestalg SHA1 -keystore p2pconnect.keystore app/build/outputs/apk/release/app-release-unsigned.apk p2pconnect

# محاذاة APK
zipalign -v 4 app/build/outputs/apk/release/app-release-unsigned.apk app/build/outputs/apk/release/p2pconnect-v1.0.0.apk
```

### 3. رفع APK لواجهة الإدارة

```bash
# نسخ APK إلى مجلد الرفع
cp app/build/outputs/apk/release/p2pconnect-v1.0.0.apk /home/p2pconnect/uploads/

# تحديث قاعدة البيانات عبر واجهة الإدارة
# اذهب إلى https://admin.p2pconnect.app
# سجل الدخول وارفع الإصدار الجديد
```

## 📊 المراقبة والصيانة

### 1. إعداد مراقبة النظام

```bash
# تثبيت htop لمراقبة الموارد
sudo apt install htop

# إعداد مراقبة اللوجز
sudo apt install logrotate

# إنشاء تكوين logrotate
sudo tee /etc/logrotate.d/p2pconnect << EOF
/var/log/p2pconnect/*.log {
    daily
    missingok
    rotate 30
    compress
    delaycompress
    notifempty
    create 644 p2pconnect p2pconnect
    postrotate
        pm2 reload all
    endscript
}
EOF
```

### 2. إعداد النسخ الاحتياطي

```bash
# إنشاء سكريبت النسخ الاحتياطي
cat > ~/backup.sh << 'EOF'
#!/bin/bash
BACKUP_DIR="/home/p2pconnect/backups"
DATE=$(date +%Y%m%d_%H%M%S)

mkdir -p $BACKUP_DIR

# نسخ احتياطي لقاعدة البيانات
cp ~/apps/p2pconnect/admin_web/p2pconnect.db $BACKUP_DIR/db_$DATE.db

# نسخ احتياطي للملفات المرفوعة
tar -czf $BACKUP_DIR/uploads_$DATE.tar.gz /home/p2pconnect/uploads/

# حذف النسخ القديمة (أكثر من 30 يوم)
find $BACKUP_DIR -name "*.db" -mtime +30 -delete
find $BACKUP_DIR -name "*.tar.gz" -mtime +30 -delete

echo "Backup completed: $DATE"
EOF

chmod +x ~/backup.sh

# إضافة مهمة cron للنسخ الاحتياطي اليومي
(crontab -l 2>/dev/null; echo "0 2 * * * /home/p2pconnect/backup.sh") | crontab -
```

### 3. مراقبة الأداء

```bash
# إنشاء سكريبت مراقبة
cat > ~/monitor.sh << 'EOF'
#!/bin/bash

# فحص حالة الخدمات
echo "=== Service Status ==="
pm2 status
systemctl status p2p-admin --no-pager -l

# فحص استخدام الموارد
echo -e "\n=== Resource Usage ==="
free -h
df -h
top -bn1 | head -20

# فحص اللوجز للأخطاء
echo -e "\n=== Recent Errors ==="
tail -50 /var/log/p2pconnect/signaling-error.log | grep ERROR || echo "No errors found"

# فحص الاتصالات النشطة
echo -e "\n=== Active Connections ==="
netstat -an | grep :3000 | wc -l
netstat -an | grep :5000 | wc -l
EOF

chmod +x ~/monitor.sh

# تشغيل المراقبة كل 5 دقائق
(crontab -l 2>/dev/null; echo "*/5 * * * * /home/p2pconnect/monitor.sh >> /var/log/p2pconnect/monitor.log 2>&1") | crontab -
```

## 🔧 استكشاف الأخطاء

### مشاكل شائعة وحلولها

#### 1. خادم الإشارة لا يعمل

```bash
# فحص الحالة
pm2 status
pm2 logs p2p-signaling

# إعادة التشغيل
pm2 restart p2p-signaling

# فحص المنافذ
sudo netstat -tlnp | grep :3000
```

#### 2. واجهة الإدارة لا تعمل

```bash
# فحص الحالة
sudo systemctl status p2p-admin

# فحص اللوجز
sudo journalctl -u p2p-admin -f

# إعادة التشغيل
sudo systemctl restart p2p-admin
```

#### 3. مشاكل SSL

```bash
# تجديد الشهادات
sudo certbot renew --dry-run
sudo certbot renew

# فحص انتهاء الصلاحية
sudo certbot certificates
```

#### 4. مشاكل الأداء

```bash
# فحص استخدام الموارد
htop
iotop
nethogs

# فحص اللوجز للأخطاء
tail -f /var/log/nginx/error.log
tail -f /var/log/p2pconnect/signaling-error.log
```

### أوامر مفيدة للصيانة

```bash
# إعادة تشغيل جميع الخدمات
pm2 restart all
sudo systemctl restart p2p-admin
sudo systemctl reload nginx

# فحص حالة النظام
~/monitor.sh

# تنظيف اللوجز
sudo truncate -s 0 /var/log/p2pconnect/*.log

# تحديث المشروع
cd ~/apps/p2pconnect
git pull origin main
npm install --production
pm2 restart all
```

## 📋 قائمة التحقق النهائية

### قبل النشر

- [ ] تم تحديث جميع المتغيرات في ملفات `.env`
- [ ] تم إعداد OAuth credentials بشكل صحيح
- [ ] تم إعداد Firebase وتحميل `google-services.json`
- [ ] تم إعداد Google Apps Script ونشره
- [ ] تم اختبار جميع الخدمات محلياً
- [ ] تم إنشاء النسخ الاحتياطية

### بعد النشر

- [ ] جميع الخدمات تعمل بشكل صحيح
- [ ] SSL certificates مثبتة وتعمل
- [ ] تطبيق Android يتصل بالخوادم
- [ ] واجهة الإدارة تعمل وتقبل رفع الملفات
- [ ] صفحة التحميل تعرض الإصدار الصحيح
- [ ] الإشعارات تعمل عبر Firebase
- [ ] جمع الإيميلات يعمل عبر Google Sheets

### المراقبة المستمرة

- [ ] مراقبة اللوجز للأخطاء
- [ ] مراقبة استخدام الموارد
- [ ] فحص حالة الخدمات دورياً
- [ ] تحديث النظام والتبعيات
- [ ] تجديد SSL certificates
- [ ] إجراء النسخ الاحتياطية

---

**ملاحظة:** هذا الدليل يفترض استخدام Ubuntu 20.04 LTS. قد تحتاج لتعديل بعض الأوامر حسب نظام التشغيل المستخدم.

للحصول على المساعدة، راجع [وثائق المشروع](README.md) أو تواصل مع فريق الدعم.

