/**
 * Load Testing Script for P2P Signaling Server
 * 
 * This script tests the signaling server under various load conditions:
 * - Concurrent session creation
 * - Multiple participants joining sessions
 * - WebSocket connection stress
 * - Memory and CPU usage monitoring
 */

const WebSocket = require('ws');
const axios = require('axios');
const { performance } = require('perf_hooks');

class LoadTester {
    constructor(serverUrl = 'http://localhost:3000', wsUrl = 'ws://localhost:3000') {
        this.serverUrl = serverUrl;
        this.wsUrl = wsUrl;
        this.sessions = [];
        this.connections = [];
        this.metrics = {
            sessionsCreated: 0,
            participantsJoined: 0,
            wsConnections: 0,
            errors: 0,
            responseTime: [],
            memoryUsage: [],
            startTime: null,
            endTime: null
        };
    }

    async runLoadTest() {
        console.log('🚀 Starting Load Test for P2P Signaling Server');
        console.log(`Server URL: ${this.serverUrl}`);
        console.log(`WebSocket URL: ${this.wsUrl}`);
        
        this.metrics.startTime = performance.now();

        try {
            // Test 1: Concurrent Session Creation
            await this.testConcurrentSessionCreation(50);
            
            // Test 2: Multiple Participants per Session
            await this.testMultipleParticipants(10, 5);
            
            // Test 3: WebSocket Connection Stress
            await this.testWebSocketStress(100);
            
            // Test 4: Mixed Load (Sessions + Participants + WebSockets)
            await this.testMixedLoad(20, 3, 50);
            
            // Test 5: Rate Limiting Test
            await this.testRateLimiting(100);
            
        } catch (error) {
            console.error('❌ Load test failed:', error);
            this.metrics.errors++;
        } finally {
            this.metrics.endTime = performance.now();
            await this.cleanup();
            this.generateReport();
        }
    }

    async testConcurrentSessionCreation(count) {
        console.log(`\n📊 Test 1: Creating ${count} concurrent sessions...`);
        
        const promises = [];
        const startTime = performance.now();
        
        for (let i = 0; i < count; i++) {
            promises.push(this.createSession(`user-${i}`, `User ${i}`, `device-${i}`));
        }
        
        try {
            const results = await Promise.allSettled(promises);
            const successful = results.filter(r => r.status === 'fulfilled').length;
            const failed = results.filter(r => r.status === 'rejected').length;
            
            const endTime = performance.now();
            const duration = endTime - startTime;
            
            console.log(`✅ Sessions created: ${successful}/${count}`);
            console.log(`❌ Failed: ${failed}`);
            console.log(`⏱️  Duration: ${duration.toFixed(2)}ms`);
            console.log(`📈 Rate: ${(successful / (duration / 1000)).toFixed(2)} sessions/sec`);
            
            this.metrics.sessionsCreated += successful;
            this.metrics.errors += failed;
            this.metrics.responseTime.push(duration / count);
            
        } catch (error) {
            console.error('❌ Concurrent session creation failed:', error);
            this.metrics.errors++;
        }
    }

    async testMultipleParticipants(sessionCount, participantsPerSession) {
        console.log(`\n👥 Test 2: Adding ${participantsPerSession} participants to ${sessionCount} sessions...`);
        
        // Create sessions first
        const sessionPromises = [];
        for (let i = 0; i < sessionCount; i++) {
            sessionPromises.push(this.createSession(`creator-${i}`, `Creator ${i}`, `creator-device-${i}`));
        }
        
        const sessionResults = await Promise.allSettled(sessionPromises);
        const successfulSessions = sessionResults
            .filter(r => r.status === 'fulfilled')
            .map(r => r.value);
        
        console.log(`📝 Created ${successfulSessions.length} sessions for participant testing`);
        
        // Add participants to each session
        const participantPromises = [];
        const startTime = performance.now();
        
        for (const session of successfulSessions) {
            for (let j = 0; j < participantsPerSession; j++) {
                const participantId = `participant-${session.sessionId}-${j}`;
                participantPromises.push(
                    this.joinSession(session.sessionId, participantId, `Participant ${j}`, `device-${participantId}`)
                );
            }
        }
        
        try {
            const results = await Promise.allSettled(participantPromises);
            const successful = results.filter(r => r.status === 'fulfilled').length;
            const failed = results.filter(r => r.status === 'rejected').length;
            
            const endTime = performance.now();
            const duration = endTime - startTime;
            
            console.log(`✅ Participants joined: ${successful}/${participantPromises.length}`);
            console.log(`❌ Failed: ${failed}`);
            console.log(`⏱️  Duration: ${duration.toFixed(2)}ms`);
            
            this.metrics.participantsJoined += successful;
            this.metrics.errors += failed;
            
        } catch (error) {
            console.error('❌ Multiple participants test failed:', error);
            this.metrics.errors++;
        }
    }

    async testWebSocketStress(connectionCount) {
        console.log(`\n🔌 Test 3: Creating ${connectionCount} WebSocket connections...`);
        
        const promises = [];
        const startTime = performance.now();
        
        for (let i = 0; i < connectionCount; i++) {
            promises.push(this.createWebSocketConnection(`ws-user-${i}`));
        }
        
        try {
            const results = await Promise.allSettled(promises);
            const successful = results.filter(r => r.status === 'fulfilled').length;
            const failed = results.filter(r => r.status === 'rejected').length;
            
            const endTime = performance.now();
            const duration = endTime - startTime;
            
            console.log(`✅ WebSocket connections: ${successful}/${connectionCount}`);
            console.log(`❌ Failed: ${failed}`);
            console.log(`⏱️  Duration: ${duration.toFixed(2)}ms`);
            
            this.metrics.wsConnections += successful;
            this.metrics.errors += failed;
            
            // Keep connections open for a while to test sustained load
            console.log('⏳ Keeping connections open for 10 seconds...');
            await this.sleep(10000);
            
        } catch (error) {
            console.error('❌ WebSocket stress test failed:', error);
            this.metrics.errors++;
        }
    }

    async testMixedLoad(sessionCount, participantsPerSession, wsConnections) {
        console.log(`\n🔄 Test 4: Mixed load test...`);
        console.log(`   Sessions: ${sessionCount}`);
        console.log(`   Participants per session: ${participantsPerSession}`);
        console.log(`   WebSocket connections: ${wsConnections}`);
        
        const startTime = performance.now();
        const allPromises = [];
        
        // Create sessions
        for (let i = 0; i < sessionCount; i++) {
            allPromises.push(this.createSession(`mixed-user-${i}`, `Mixed User ${i}`, `mixed-device-${i}`));
        }
        
        // Create WebSocket connections
        for (let i = 0; i < wsConnections; i++) {
            allPromises.push(this.createWebSocketConnection(`mixed-ws-${i}`));
        }
        
        try {
            const results = await Promise.allSettled(allPromises);
            const successful = results.filter(r => r.status === 'fulfilled').length;
            const failed = results.filter(r => r.status === 'rejected').length;
            
            const endTime = performance.now();
            const duration = endTime - startTime;
            
            console.log(`✅ Mixed operations successful: ${successful}/${allPromises.length}`);
            console.log(`❌ Failed: ${failed}`);
            console.log(`⏱️  Duration: ${duration.toFixed(2)}ms`);
            
            this.metrics.errors += failed;
            
        } catch (error) {
            console.error('❌ Mixed load test failed:', error);
            this.metrics.errors++;
        }
    }

    async testRateLimiting(requestCount) {
        console.log(`\n🚦 Test 5: Rate limiting test with ${requestCount} rapid requests...`);
        
        const promises = [];
        const startTime = performance.now();
        
        // Send many requests rapidly from the same "user"
        for (let i = 0; i < requestCount; i++) {
            promises.push(this.createSession('rate-test-user', 'Rate Test User', `rate-device-${i}`));
        }
        
        try {
            const results = await Promise.allSettled(promises);
            const successful = results.filter(r => r.status === 'fulfilled').length;
            const rateLimited = results.filter(r => 
                r.status === 'rejected' && 
                r.reason?.response?.status === 429
            ).length;
            const otherErrors = results.filter(r => 
                r.status === 'rejected' && 
                r.reason?.response?.status !== 429
            ).length;
            
            const endTime = performance.now();
            const duration = endTime - startTime;
            
            console.log(`✅ Successful requests: ${successful}`);
            console.log(`🚦 Rate limited (429): ${rateLimited}`);
            console.log(`❌ Other errors: ${otherErrors}`);
            console.log(`⏱️  Duration: ${duration.toFixed(2)}ms`);
            
            if (rateLimited > 0) {
                console.log('✅ Rate limiting is working correctly');
            } else {
                console.log('⚠️  Rate limiting may not be configured properly');
            }
            
        } catch (error) {
            console.error('❌ Rate limiting test failed:', error);
            this.metrics.errors++;
        }
    }

    async createSession(userId, userName, deviceId) {
        const sessionData = {
            sessionType: 'desk',
            userId,
            userName,
            deviceId
        };
        
        const response = await axios.post(`${this.serverUrl}/api/sessions`, sessionData);
        this.sessions.push(response.data);
        return response.data;
    }

    async joinSession(sessionId, userId, userName, deviceId) {
        const joinData = {
            userId,
            userName,
            deviceId
        };
        
        const response = await axios.post(`${this.serverUrl}/api/sessions/${sessionId}/join`, joinData);
        return response.data;
    }

    async createWebSocketConnection(userId) {
        return new Promise((resolve, reject) => {
            const ws = new WebSocket(this.wsUrl);
            
            const timeout = setTimeout(() => {
                ws.close();
                reject(new Error('WebSocket connection timeout'));
            }, 5000);
            
            ws.on('open', () => {
                clearTimeout(timeout);
                this.connections.push(ws);
                
                // Send a test message
                ws.send(JSON.stringify({
                    type: 'join',
                    sessionId: 'test-session',
                    userId: userId
                }));
                
                resolve(ws);
            });
            
            ws.on('error', (error) => {
                clearTimeout(timeout);
                reject(error);
            });
        });
    }

    async cleanup() {
        console.log('\n🧹 Cleaning up connections...');
        
        // Close all WebSocket connections
        for (const ws of this.connections) {
            if (ws.readyState === WebSocket.OPEN) {
                ws.close();
            }
        }
        
        console.log(`✅ Closed ${this.connections.length} WebSocket connections`);
    }

    generateReport() {
        console.log('\n📊 LOAD TEST REPORT');
        console.log('='.repeat(50));
        
        const duration = (this.metrics.endTime - this.metrics.startTime) / 1000;
        const avgResponseTime = this.metrics.responseTime.length > 0 
            ? this.metrics.responseTime.reduce((a, b) => a + b, 0) / this.metrics.responseTime.length 
            : 0;
        
        console.log(`⏱️  Total Duration: ${duration.toFixed(2)} seconds`);
        console.log(`📈 Sessions Created: ${this.metrics.sessionsCreated}`);
        console.log(`👥 Participants Joined: ${this.metrics.participantsJoined}`);
        console.log(`🔌 WebSocket Connections: ${this.metrics.wsConnections}`);
        console.log(`❌ Total Errors: ${this.metrics.errors}`);
        console.log(`📊 Average Response Time: ${avgResponseTime.toFixed(2)}ms`);
        console.log(`🚀 Sessions/sec: ${(this.metrics.sessionsCreated / duration).toFixed(2)}`);
        console.log(`👥 Participants/sec: ${(this.metrics.participantsJoined / duration).toFixed(2)}`);
        
        // Performance assessment
        console.log('\n🎯 PERFORMANCE ASSESSMENT');
        console.log('-'.repeat(30));
        
        if (this.metrics.errors === 0) {
            console.log('✅ No errors detected - Excellent stability');
        } else if (this.metrics.errors < 10) {
            console.log('⚠️  Few errors detected - Good stability');
        } else {
            console.log('❌ Many errors detected - Poor stability');
        }
        
        if (avgResponseTime < 100) {
            console.log('✅ Fast response times - Excellent performance');
        } else if (avgResponseTime < 500) {
            console.log('⚠️  Moderate response times - Good performance');
        } else {
            console.log('❌ Slow response times - Poor performance');
        }
        
        const totalOperations = this.metrics.sessionsCreated + this.metrics.participantsJoined + this.metrics.wsConnections;
        const operationsPerSecond = totalOperations / duration;
        
        if (operationsPerSecond > 50) {
            console.log('✅ High throughput - Excellent scalability');
        } else if (operationsPerSecond > 20) {
            console.log('⚠️  Moderate throughput - Good scalability');
        } else {
            console.log('❌ Low throughput - Poor scalability');
        }
        
        console.log('\n🏁 Load test completed!');
    }

    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}

// Run the load test
async function main() {
    const serverUrl = process.env.SERVER_URL || 'http://localhost:3000';
    const wsUrl = process.env.WS_URL || 'ws://localhost:3000';
    
    const tester = new LoadTester(serverUrl, wsUrl);
    await tester.runLoadTest();
}

// Handle graceful shutdown
process.on('SIGINT', () => {
    console.log('\n⏹️  Load test interrupted by user');
    process.exit(0);
});

process.on('SIGTERM', () => {
    console.log('\n⏹️  Load test terminated');
    process.exit(0);
});

if (require.main === module) {
    main().catch(error => {
        console.error('❌ Load test failed:', error);
        process.exit(1);
    });
}

module.exports = LoadTester;

